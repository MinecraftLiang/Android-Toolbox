package com.mcyi.main.modules.toolopen

//基础库
import android.content.Context
import android.content.Intent
//工具文本活动
import com.mcyi.editor.TextEditor.TextEditorActivity
import com.mcyi.tool.text.TextOperateActivity
import com.mcyi.tool.text.UUIDActivity
import com.mcyi.tool.text.ScaleConversionActivity

public class TextOpen(private val mContext: Context) {

    public fun Open(index : Int) {
        when (index) {
            //文本编辑器
            0 -> {
                val intent = Intent(mContext, TextEditorActivity::class.java)
                mContext.startActivity(intent)
            }
            //文本操作
            1 -> {
                val intent = Intent(mContext, TextOperateActivity::class.java)
                mContext.startActivity(intent)
            }
            //UUID生成
            2 -> {
                val intent = Intent(mContext, UUIDActivity::class.java)
                mContext.startActivity(intent)
            }
            //进制转换
            3 -> {
                val intent = Intent(mContext, ScaleConversionActivity::class.java)
                mContext.startActivity(intent)
            }
            else -> {}
        }
    }


}
