package com.mcyi.editor.TextEditor

import android.content.Context
import android.widget.EditText
import android.text.Editable
import android.text.Selection

import com.mcyi.android.tool.SystemOperation

public class EditModule(private val mContext: Context,private val mEditText: EditText) {
    
    
    //初始化
    init {
        
    }
    
    //复制
    public fun Copy() {
        SystemOperation.setClipboardText(mContext,getText())
    }
    
    //复制行
    public fun CopyRow() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val currentLineText = mEditText.text.substring(start, end) // 获取光标所在行的文本内容
        SystemOperation.setClipboardText(mContext,currentLineText.toString())
    }
    
    //剪切行
    public fun CutLine() {
        CopyRow()
        EmptyLine()
    }
    
    //删除行
    public fun DeleteRow() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val lineStart = start
        var lineEnd = end
        // 删除当前行的内容
        if (lineEnd < mEditText.text.length && mEditText.text[lineEnd] == '\n') {
            lineEnd++ // 包括末尾的换行符
        }
        val editable = mEditText.editableText
        editable.delete(lineStart, lineEnd) // 删除光标所在行的文本内容
        // 调整行号
        val lineNumber = mEditText.layout.getLineForOffset(cursorPosition)
        val newLineCount = mEditText.layout.lineCount - 1.0f // 计算删除一行后的总行数
        mEditText.setText(mEditText.text.toString()) // 重新设置文本，此步骤将触发文本重新绘制和更新行数
        val offsetForNewLine = mEditText.layout.getOffsetForHorizontal(newLineCount.toInt(), 0f) // 获取删除操作后的正确光标位置
        mEditText.setSelection(offsetForNewLine) // 将光标移动到删除操作后的正确位置
        //
    }
    
    //清空行
    public fun EmptyLine() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val editable = mEditText.editableText
        editable.delete(start, end) // 删除光标所在行的文本内容
    }
    
    //替换行
    public fun ReplaceRow() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val lineStart = start
        var lineEnd = end
        // 替换光标所在行的内容
        val newText = SystemOperation.getClipboardText(mContext) // 替换为您设置的新值
        val editable = mEditText.editableText
        editable.replace(lineStart, lineEnd, newText) // 用新内容替换光标所在行的文本内容
    }
    
    //重复行
    public fun DuplicateRow() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val lineStart = start
        var lineEnd = end
        // 获取光标当前行的内容
        val currentLineText = mEditText.text.subSequence(lineStart, lineEnd)
        // 插入文本到下一行
        val editable = mEditText.editableText
        editable.insert(lineEnd, "\n") // 插入一个换行符
        editable.insert(lineEnd + 1, currentLineText) // 插入光标当前行的内容到下一行
    }
    
    //转为大写
    public fun ToUppercase() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val lineStart = start
        var lineEnd = end
        // 将光标当前行的内容设为大写
        val editable = mEditText.editableText
        val uppercaseText = mEditText.text.substring(lineStart, lineEnd).toUpperCase() // 将光标当前行的内容转换为大写
        editable.replace(lineStart, lineEnd, uppercaseText) // 用大写的内容替换光标所在行的文本内容
    }
    
    //转为小写
    public fun ToLowercase() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        val lineStart = start
        var lineEnd = end
        // 将光标当前行的内容设为小写
        val editable = mEditText.editableText
        val uppercaseText = mEditText.text.substring(lineStart, lineEnd).toLowerCase() // 将光标当前行的内容转换为大写
        editable.replace(lineStart, lineEnd, uppercaseText) // 用大写的内容替换光标所在行的文本内容
    }
    
    //---内部相关方法---
    private fun getText() : String {
        return mEditText.getText().toString()
    }
    
}
