package com.mcyi.editor.TextEditor

import java.util.ArrayList
import android.widget.EditText
import android.content.Context
import android.widget.LinearLayout
import android.widget.Button
import android.graphics.Typeface
import android.util.TypedValue
import android.view.ViewGroup

import com.mcyi.android.tool.PixelOperation


public class SymbolModules(private val mContext: Context,
            private val mEditText: EditText,
            private val mLinearLayout: LinearLayout) {
            
    var list_array : Array<String> = arrayOf()

    //初始化
    init {
        list_array = arrayOf("，","。","？","！","：","；","……","～","、","（）","@","《》")
    }
    
    //list
    public fun list() {
        val mPixelOperation = PixelOperation()
        mLinearLayout.removeAllViews()
        var i = 0
        while (i < list_array.size) {
            //设置
            val mButton = Button(mContext)
            mButton.setText(list_array[i])
            mButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            mButton.setBackgroundColor(-526087)
            // 设置宽度和高度
            val layoutParams = ViewGroup.LayoutParams(
                mPixelOperation.DPtoPX(mContext,40), // 设置宽度为40dp
                mPixelOperation.DPtoPX(mContext,40)  // 设置高度为40dp
            )
            mButton.layoutParams = layoutParams
            //添加
            mLinearLayout.addView(mButton)
            //设置监听器
            mButton.setOnClickListener {
                Insert_Text(mButton.getText().toString())
            }
            i++
        }
    }
    
    //插入文本
    private fun Insert_Text(tex : String) {
        val position = mEditText.selectionStart // 获取光标的位置
        val editable = mEditText.text
        editable.insert(position, tex) // 在光标位置插入文本
    }

}
