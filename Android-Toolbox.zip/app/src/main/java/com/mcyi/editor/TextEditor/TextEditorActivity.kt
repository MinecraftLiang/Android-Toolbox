package com.mcyi.editor.TextEditor

//基本库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
//
import android.content.Intent
import android.app.Activity
import android.net.Uri
import android.widget.Toast
//
import android.view.View
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import android.widget.ProgressBar
import android.widget.ListView
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
import androidx.appcompat.widget.PopupMenu
//线程
import android.os.Handler
import android.os.Looper
//App
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.utils.FileHelper
import com.mcyi.android.tool2.FileOperation
//文本编辑器
import com.mcyi.editor.TextEditor.ToolbarModule
import com.mcyi.editor.TextEditor.ZoomModule
import com.mcyi.editor.TextEditor.CursorModule
import com.mcyi.editor.TextEditor.EditModule
import com.mcyi.editor.TextEditor.MarkingModule
import com.mcyi.editor.TextEditor.SymbolModules
import com.mcyi.editor.TextEditor.FileModules
import com.mcyi.editor.TextEditor.ComplementModules

public class TextEditorActivity : AppCompatActivity() {

    //
    private lateinit var text_editor : EditText
    private lateinit var symbols_layout : LinearLayout
    private lateinit var file_list : ListView
    private lateinit var completion : LinearLayout

    //文本编辑器模块
    private var mToolbarModule : ToolbarModule? = null
    private var mZoomModule : ZoomModule? = null
    private var mCursorModule : CursorModule? = null
    private var mEditModule : EditModule? = null
    private var mMarkingModule : MarkingModule? = null
    private var mSymbolModules : SymbolModules? = null
    private var mFileModules : FileModules? = null
    private var mComplementModules : ComplementModules? = null
    
    //选项
    private var mOptionReadOnly : Boolean = false
    private var mOptionWordWrap : Boolean = false
    private var mOptionSymbols : Boolean = false
    private var mOptionCompletion : Boolean = false
    
    private var mfsearch : Boolean = false
    private var mfreplace : Boolean = false
    
    //
    var path: String? = null
    

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //内容视图
        setContentView(R.layout.activity_editor_text_editor)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#ffffff")
        ApplicationWindow.StatusBarFontBlack(this,true)
        //设置工具栏
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "文本编辑器"
        setSupportActionBar(toolbar)
        //文本编辑器模块初始化
        text_editor = findViewById<EditText>(R.id.text_editor)
        symbols_layout = findViewById<LinearLayout>(R.id.symbols)
        completion = findViewById<LinearLayout>(R.id.completion)
        file_list = findViewById<ListView>(R.id.file_list)
        mToolbarModule = ToolbarModule(text_editor)
        mZoomModule = ZoomModule(this,text_editor)
        mCursorModule = CursorModule(this,text_editor)
        mEditModule = EditModule(this,text_editor)
        mMarkingModule = MarkingModule(this,text_editor)
        mSymbolModules = SymbolModules(this,text_editor,symbols_layout)
        mComplementModules = ComplementModules(this,text_editor,completion)
        //左侧文件列表
        var patha = getExternalFilesDir(null)?.absolutePath
        var paths = patha.toString() + "/editor/TextEditor"
        var mFileOperation : FileOperation = FileOperation()
        if (mFileOperation.Exists(paths)) {
            mFileModules = FileModules(this,file_list,paths)
        } else {
            mFileOperation.CreateDirectory(paths)
            mFileModules = FileModules(this,file_list,paths)
        }
        //文件模块列表点击接听器
        val mFileDrawerLayout = findViewById<DrawerLayout>(R.id.file_drawer_layout)
        var fileModules = mFileModules
        fileModules!!.setOnFileListener(object : FileModules.OnFileListener {
            override fun onSelected(pathss: String) {
                //打开文件
                path = pathss
                OpenFile(pathss)
                //关闭侧滑
                mFileDrawerLayout.closeDrawer(Gravity.LEFT)
            }
        })
        //按钮被点击监听器
        var add_file_button: LinearLayout = findViewById(R.id.add_file_button)
        add_file_button.setOnClickListener {
            fileModules!!.addFile()
        }
        //加载方法
        Inil()
    }
    
    //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_editor_text_editor, menu)
        return true
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //获取控件属性
        val mFileDrawerLayout = findViewById<DrawerLayout>(R.id.file_drawer_layout)
        val mFileToolbar = findViewById<Toolbar>(R.id.file_toolbar)
        when (item.itemId) {
            //打开侧滑栏
            android.R.id.home -> {
                if (mFileDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    mFileDrawerLayout.closeDrawer(Gravity.LEFT)
                    } else {
                     mFileDrawerLayout.openDrawer(Gravity.LEFT)
                }
            }
            //撤销
            R.id.undo -> {
                val toolbarModule = mToolbarModule
                if (toolbarModule != null) {
                    toolbarModule.undo()
                }  
                return true
            }
            //重做
            R.id.redo -> {
                val toolbarModule = mToolbarModule
                if (toolbarModule != null) {
                    toolbarModule.redo()
                }  
                return true
            }
            //菜单
            R.id.menu -> {
                MenuOptionFunction(findViewById(R.id.toolbar))
                return true
            }
        }
        //设置标题
        mFileToolbar.title = "快捷列表"
        //
        return super.onOptionsItemSelected(item)
    }
    
    //初始化
    private fun Inil() {
        //关闭编辑框默认自动换行
        text_editor.setHorizontallyScrolling(true)
        //
        val symbolModules = mSymbolModules
        //初始化符号栏
        if (symbolModules != null) {
            symbolModules.list()
        }
    }
    
   //菜单选项功能
    private fun MenuOptionFunction(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.menu_editor_text_menu, popupMenu.menu)
        //---选项---
        //只读模式
        val item_option_read_only: MenuItem = popupMenu.menu.findItem(R.id.option_read_only)
        item_option_read_only.isChecked = mOptionReadOnly
        //自动换行
        val item_option_word_wrap: MenuItem = popupMenu.menu.findItem(R.id.option_word_wrap)
        item_option_word_wrap.isChecked = mOptionWordWrap
        //符号栏
        val item_option_symbols: MenuItem = popupMenu.menu.findItem(R.id.option_symbols)
        item_option_symbols.isChecked = mOptionSymbols
        //自动补全
        val item_option_completion: MenuItem = popupMenu.menu.findItem(R.id.option_completion)
        item_option_completion.isChecked = mOptionCompletion
        popupMenu.setOnMenuItemClickListener { menuItem ->
            val editModule = mEditModule
            val cursorModule = mCursorModule
            val markingModule = mMarkingModule
            when (menuItem.itemId) {
                //文件
                 //打开文件
                 R.id.open_file -> {
                         intoFileManager()
                      true
                 }
                 //保存文件
                 R.id.save_file -> {
                         SaveFile()
                      true
                 }
                 //关闭文件
                 R.id.close_file -> {
                      path = ""
                      true
                 }
                //编辑
                 //复制
                 R.id.copy -> {
                        if (editModule != null) {
                            editModule.Copy()
                        }  
                      true
                 }
                 //复制行
                 R.id.copy_row -> {
                        if (editModule != null) {
                            editModule.CopyRow()
                        }  
                      true
                 }
                 //剪切行
                 R.id.cut_line -> {
                        if (editModule != null) {
                            editModule.CutLine()
                        }  
                      true
                 }
                 //删除行
                 R.id.delete_row -> {
                        if (editModule != null) {
                            editModule.DeleteRow()
                        }  
                      true
                 }
                 //清空行
                 R.id.empty_line -> {
                        if (editModule != null) {
                            editModule.EmptyLine()
                        }  
                      true
                 }
                 
                 //替换行
                 R.id.replace_row -> {
                        if (editModule != null) {
                            editModule.ReplaceRow()
                        }  
                      true
                 }
                 //重复行
                 R.id.duplicate_row -> {
                        if (editModule != null) {
                            editModule.DuplicateRow()
                        }  
                      true
                 }
                 //转为大写
                 R.id.to_uppercase -> {
                        if (editModule != null) {
                            editModule.ToUppercase()
                        }  
                      true
                 }
                 //转为小写
                 R.id.to_lowercase -> {
                        if (editModule != null) {
                            editModule.ToLowercase()
                        }  
                      true
                 }
                //标记
                 //文字高亮
                 R.id.marking_highlight -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.highlightText(selectionStart,selectionEnd,-12349425)
                        }  
                      true
                 }
                 //文字背景
                 R.id.marking_background -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.setHighlightedBackground(selectionStart,selectionEnd,-9181)
                        }  
                      true
                 }
                 //文字下划线
                 R.id.marking_underline -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.underlineText(selectionStart,selectionEnd)
                        }  
                      true
                 }
                 //文字斜体
                 R.id.marking_italic -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.italicText(selectionStart,selectionEnd)
                        }  
                      true
                 }
                 //文字粗体
                 R.id.marking_bold -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.boldText(selectionStart,selectionEnd)
                        }  
                      true
                 }
                 //文字删除线
                 R.id.marking_strikethrough -> {
                        if (markingModule != null) {
                            val selectionStart = text_editor.selectionStart
                            val selectionEnd = text_editor.selectionEnd
                            markingModule.strikethroughText(selectionStart,selectionEnd)
                        }  
                      true
                 }
                //光标
                 //行首 
                 R.id.cursor_head_line -> {
                        if (cursorModule != null) {
                            cursorModule.HeadLine()
                        }  
                      true
                 }
                 //行尾
                 R.id.cursor_end_line -> {
                        if (cursorModule != null) {
                            cursorModule.EndLine()
                        }  
                      true
                 }
                 //全文首
                 R.id.cursor_head -> {
                        if (cursorModule != null) {
                            cursorModule.Head()
                        }  
                      true
                 }
                 //全文尾
                 R.id.cursor_end -> {
                        if (cursorModule != null) {
                            cursorModule.End()
                        }  
                      true
                 }
                 //撤销
                 R.id.cursor_up -> {
                        if (cursorModule != null) {
                            cursorModule.Undo()
                        }  
                      true
                 }
                 //重做
                 R.id.cursor_down -> {
                        if (cursorModule != null) {
                            cursorModule.Redo()
                        }  
                      true
                 }
                 //列表
                 R.id.cursor_list -> {
                        if (cursorModule != null) {
                            cursorModule.List()
                        }  
                      true
                 }
                //搜索
                R.id.find -> {
                    mfsearch = true
                      val search_s_layout = findViewById<HorizontalScrollView>(R.id.search_s_layout) 
                      val mfind_button = findViewById<LinearLayout>(R.id.find_button)
                      search_s_layout.visibility = View.VISIBLE
                      mfind_button.setOnClickListener {
                          searchAndSelectText()
                      }
                      true
                }
                //替换
                R.id.substitution -> {
                      mfreplace = true
                      val search_editor: EditText = findViewById<EditText>(R.id.find_editor)
                      val substitution_editor = findViewById<EditText>(R.id.substitution_editor) 
                      val substitution_layout = findViewById<LinearLayout>(R.id.substitution_layout) 
                      substitution_editor.visibility = View.VISIBLE
                      substitution_layout.visibility = View.VISIBLE
                      substitution_layout.setOnClickListener {
                         var at = text_editor.getText().toString()
                         var at1 = search_editor.getText().toString()
                         var at2 = substitution_editor.getText().toString()
                         var at3 = at.replace(at1,at2)
                         text_editor.setText(at3)
                         Toast.makeText(this, "替换成功！", Toast.LENGTH_SHORT).show() 
                      }
                      true
                }
                //选项
                 //只读模式
                  R.id.option_read_only -> {
                      mOptionReadOnly = !mOptionReadOnly
                      menuItem.isChecked = !mOptionReadOnly
                      text_editor.setEnabled(!mOptionReadOnly)
                      true
                  }
                  //自动换行  
                  R.id.option_word_wrap -> {
                      mOptionWordWrap = !mOptionWordWrap
                      menuItem.isChecked = !mOptionWordWrap
                      text_editor.setHorizontallyScrolling(!mOptionWordWrap)
                      true
                  }
                  //符号栏
                  R.id.option_symbols -> {
                      mOptionSymbols = !mOptionSymbols
                      menuItem.isChecked = !mOptionSymbols
                      val symbols_layout = findViewById<HorizontalScrollView>(R.id.symbols_layout) 
                      if (mOptionSymbols) {
                          symbols_layout.visibility = View.VISIBLE
                      } else {
                          symbols_layout.visibility = View.GONE
                      }
                      true
                  }
                  //自动补全
                  R.id.option_completion -> {
                      mOptionCompletion = !mOptionCompletion
                      menuItem.isChecked = !mOptionCompletion
                      val completion = findViewById<HorizontalScrollView>(R.id.completion_layout) 
                      var complementModules = mComplementModules
                      if (mOptionCompletion) {
                          completion.visibility = View.VISIBLE
                      } else {
                          completion.visibility = View.GONE
                      }
                      //打开补全模块
                      if (complementModules != null) {
                          complementModules.Completion(mOptionCompletion)
                      }
                      true
                  }
                else -> false
            }
        }
        popupMenu.setGravity(5)
        popupMenu.show() 
    }
    
    //选择文件管理器
    private fun intoFileManager() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*" // 无类型限制
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, 1)
    }
    
    //软件回调事件
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                path = FileHelper.getFileAbsolutePath(this, uri)
                if (path != null) {
                    OpenFile(path.toString())
                }
            }
        }
    }
    
    //返回键被按下
    override fun onBackPressed() {
        if (mfsearch) {
            mfsearch = false
            val search_s_layout = findViewById<HorizontalScrollView>(R.id.search_s_layout) 
            search_s_layout.visibility = View.GONE
        } else {
            super.onBackPressed()
        }
        if (mfreplace) {
            mfreplace = false
            val substitution_editor = findViewById<EditText>(R.id.substitution_editor) 
            val substitution_layout = findViewById<LinearLayout>(R.id.substitution_layout) 
            substitution_editor.visibility = View.GONE
            substitution_layout.visibility = View.GONE
        } else {
            if (mfsearch) {
                super.onBackPressed()
            } 
        }
        
    }
    
    // 打开文件
    private fun OpenFile(path: String) {
        // 在后台线程中执行文件操作
        Thread {
            val mFileOperation: FileOperation = FileOperation()
    
            runOnUiThread {
                // 显示进度条
                val progressBar = findViewById<ProgressBar>(R.id.progressBar) // 获取进度条实例
                progressBar.visibility = View.VISIBLE // 显示进度条
            }
            
            val path_text: String = mFileOperation.ReadFile(path)
    
            // 在主线程更新UI
            runOnUiThread {
                val toolbarModule = mToolbarModule
                if (toolbarModule != null) {
                    toolbarModule.setText(path_text)
                }  
                val progressBar = findViewById<ProgressBar>(R.id.progressBar) // 获取进度条实例
                progressBar.visibility = View.GONE // 隐藏进度条
                // 在此处执行其他UI更新操作
            }
        }.start()
    }
    
    //保存文件
    private fun SaveFile() {
        val mFileOperation : FileOperation = FileOperation()
        if (path != null) {
            mFileOperation.WriteFile(path.toString(),text_editor.getText().toString())
        } else {
            Toast.makeText(this, "你未打开任何文件，无法保存！", Toast.LENGTH_SHORT).show()
        }
    }
    
    //查找文本
    private fun searchAndSelectText() {
        
    }
    
}