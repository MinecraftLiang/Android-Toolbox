package com.mcyi.main

//基础库
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mcyi.main.databinding.ActivityMainBinding
//content
import android.content.Intent
//活动
import com.mcyi.main.HomeActivity

import com.mcyi.main.setting.SettingActivity
//崩溃生成相关
import com.ExceptionCapture.activity.MyUncaughtExceptionHandler
import com.ExceptionCapture.activity.UncaughtExceptionActivity
//
import com.mcyi.main.main.Init

public class MainActivity : AppCompatActivity() {
    
    //保存与该活动相关联的 ActivityMainBinding 实例
    private lateinit var binding: ActivityMainBinding
    
    //App
    private var mAppInit : Init = Init()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //初始化
        Inits()
        //内容视图
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        //HomeActivity
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent) // 启动目标窗口
    }
    
    //初始化
    private fun Inits() {
        //初始化崩溃生成
        MyUncaughtExceptionHandler.getInstance(this).init();
        //生成文件
        val path = getExternalFilesDir(null)?.absolutePath
        mAppInit.path(path.toString())
        mAppInit.init()
        //
    }
    
}
