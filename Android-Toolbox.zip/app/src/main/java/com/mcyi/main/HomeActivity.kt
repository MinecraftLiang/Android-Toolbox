package com.mcyi.main;

//默认库
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//content
import android.content.Intent
//widget
import android.widget.Button
import android.widget.TextView
import android.view.LayoutInflater
import android.view.View
import com.google.android.material.tabs.TabLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.mcyi.android.view.pager.ViewPagerAdapter
import android.widget.GridView
//活动

//Array
import java.util.ArrayList
//Android App
import com.mcyi.android.foundation.ApplicationWindow
//App
import com.mcyi.main.modules.HomeTabModule
import com.mcyi.main.modules.HomeToolListModule
//pager
import com.mcyi.main.modules.pager.Centre as PagerCentre

public class HomeActivity : AppCompatActivity() {

    //
    private lateinit var viewPager : ViewPager
    private lateinit var bottomNavigationView : BottomNavigationView
    
    //

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_home)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FAFAFA")
        ApplicationWindow.StatusBarFontBlack(this,true)
         //加载方法
        Pager()
        PagerNavigationListener()
        EditorClickListener()
    }
    
    //加载分页
    private fun Pager() {
        
        val viewPager = findViewById<ViewPager>(R.id.view_pager)
        val inflate1 = LayoutInflater.from(this).inflate(R.layout.pager_main_home, null)
        val inflate2 = LayoutInflater.from(this).inflate(R.layout.pager_main_tool, null)
        val inflate3 = LayoutInflater.from(this).inflate(R.layout.pager_main_editor, null)
        val inflate4 = LayoutInflater.from(this).inflate(R.layout.pager_main_centre, null)
        val viewList: MutableList<View> = ArrayList()
        viewList.add(inflate1)
        viewList.add(inflate2)
        viewList.add(inflate3)
        viewList.add(inflate4)
        
        val adapter = ViewPagerAdapter(viewList) // ViewPagerAdapter 类需要创建
        viewPager.adapter = adapter
        
        // 获取要修改的布局
        val layout1 = viewList[0]
        val layout2 = viewList[1]
        val layout3 = viewList[2]
        val layout4 = viewList[3]
        HomeView(layout1)
        ToolView(layout2)
        EditorView(layout3)
        CentreView(layout4)
    }
    
    //监听器
    private fun PagerNavigationListener() {
        // ViewPager 的监听器
        viewPager = findViewById<ViewPager>(R.id.view_pager)
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                // 页面滑动时执行的操作
            }

            override fun onPageSelected(position: Int) {
                // 选中页面时执行的操作
            }
        
            override fun onPageScrollStateChanged(state: Int) {
                // 页面滚动状态改变时执行的操作
            }
        })
        
        // BottomNavigationView 的监听器
        bottomNavigationView = findViewById<BottomNavigationView>(R.id.navigation_view)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_item1 -> {
                    viewPager.currentItem = 0
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.menu_item2 -> {
                    viewPager.currentItem = 1
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.menu_item3 -> {
                    viewPager.currentItem = 2
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.menu_item4 -> {
                    viewPager.currentItem = 3
                    return@setOnNavigationItemSelectedListener true
                }
                else -> return@setOnNavigationItemSelectedListener false
            }
        }
        
        // 在 ViewPager 页面切换时更新 BottomNavigationView
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                // 什么都不做
            }
            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> bottomNavigationView.selectedItemId = R.id.menu_item1
                    1 -> bottomNavigationView.selectedItemId = R.id.menu_item2
                    2 -> bottomNavigationView.selectedItemId = R.id.menu_item3
                    3 -> bottomNavigationView.selectedItemId = R.id.menu_item4
                }
            }
            override fun onPageScrollStateChanged(state: Int) {
                // 什么都不做
            }
        })
    }
    
    //主页视图
    private fun HomeView(view : View) {
    }
    
    //工具视图
    private fun ToolView(view : View) {
        //初始化
        val typeTable = view.findViewById<TabLayout>(R.id.type_tab)
        val mHomeTabModule = HomeTabModule(typeTable)
        val list = view.findViewById<GridView>(R.id.list)
        val mHomeToolListModule : HomeToolListModule = HomeToolListModule(this,list)
        //分类标签栏
        mHomeTabModule.list()
        mHomeTabModule.Listener()
        mHomeTabModule.setOnTabListener(object : HomeTabModule.OnTabListener {
            override fun onSelected(index: Int) {
                mHomeToolListModule.Select(index)
            }
        })
        //列表
        mHomeToolListModule.Conversion("Text")
        mHomeToolListModule.List()
    }
    
    //编辑器视图
    private fun EditorView(view : View) {
    }
    
    //个人视图
    private fun CentreView(view : View) {
        var mPagerCentre : PagerCentre = PagerCentre(this,view)
        mPagerCentre.Listener()
    }
    
     //功能监听器
    private fun EditorClickListener() {
        /*
        //文本编辑器
        val text_button = findViewById<Button>(R.id.text_editor_button)
        text_button.setOnClickListener {
            val intent = Intent(this, CodeEditorActivity::class.java)
            startActivity(intent) // 启动目标窗口
        }
        */
    }
    
    
}