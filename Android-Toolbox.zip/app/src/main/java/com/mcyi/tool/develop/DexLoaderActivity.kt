package com.mcyi.tool.develop

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Intent
import android.app.Activity
import android.net.Uri
import android.content.Context
//widget
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import android.widget.TextView
import android.widget.LinearLayout
import com.google.android.material.textfield.TextInputEditText
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
import android.widget.PopupMenu
//
import org.json.JSONObject
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.Method
import dalvik.system.DexFile
import java.lang.reflect.InvocationTargetException
//App
import com.mcyi.main.main.Path
import com.mcyi.android.utils.FileHelper
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool2.FileOperation

public class DexLoaderActivity : AppCompatActivity() {

    //控件
    private lateinit var dexname_edit : TextInputEditText
    private lateinit var packname_edit : TextInputEditText
    private lateinit var funname_edit : TextInputEditText
    private lateinit var button_run : LinearLayout
    private lateinit var text_logs : TextView
    private lateinit var mmMenu : Menu
    //App
    private lateinit var mPath : Path
    private var mViewComponent : ViewComponent = ViewComponent()
    private var mFileOperation : FileOperation = FileOperation()
    //配置
    private var mlogs_text : String = ""
    private var static_fun : Boolean = true
    private var global_path : String = ""
    var path: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_develop_dexloader)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "Dex加载器"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        mPath = Path(this)
        Init()
    }
    
     //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu2, menu)
        Toolbar(menu)
        return true
    }
    
      //Toolbar
    private fun Toolbar(menu : Menu) {
        //导入
        val item: MenuItem = menu.findItem(R.id.menu)
        item.setIcon(R.drawable.ic_compass_outline)
        item.setTooltipText("请用静态方法")
         //切换
        val item2: MenuItem = menu.findItem(R.id.menu2)
        item2.setIcon(R.drawable.file_import)
        item2.setTooltipText("导入Dex")
        //
        mmMenu = menu
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
            //选择文件
            R.id.menu -> {
                if (static_fun) {
                    //关闭静态
                    static_fun = false
                    item.setIcon(R.drawable.ic_compass_off_outline)
                    item.setTooltipText("关闭静态方法") 
                    addLogs("dex加载器设置：已关闭静态方法")
                } else {
                    //启用静态
                    static_fun = true
                    item.setIcon(R.drawable.ic_compass_outline)
                    item.setTooltipText("启用静态方法") 
                    addLogs("dex加载器设置：已启用静态方法")
                }  
            }
            R.id.menu2 -> {
                intoFileManager()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //初始化
    private fun Init() {
        //给控件初始化
        dexname_edit = findViewById<TextInputEditText>(R.id.dexname_edit)
        packname_edit = findViewById<TextInputEditText>(R.id.packname_edit)
        funname_edit = findViewById<TextInputEditText>(R.id.funname_edit)
        button_run = findViewById<LinearLayout>(R.id.button_run)
        text_logs = findViewById<TextView>(R.id.text_logs)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,button_run)
        //加载监听器
        ClickListener()
        //初始化变量
        global_path = mPath.getToolboxPath() + "develop/dex_loader/"
        //生成相应文件
        mFileOperation.CreateDirectory(mPath.getToolboxPath() + "develop/dex_loader")
        mFileOperation.CreateDirectory(mPath.getToolboxPath() + "develop/dex_loader/dex")
    }
    
    //监听器
    private fun ClickListener() {
        //开始操作
        button_run.setOnClickListener {
           if (dexname_edit.getText().toString() == "") {
                Toast.makeText(this, "Dex名称编辑框不能为空！", Toast.LENGTH_SHORT).show()
           } else {
                summon_json(mFileOperation.getFilePrefixName(dexname_edit.getText().toString()))
                loadClassAndInvokeMethod(this)
           }
        }
        //选择名称列表
        dexname_edit.setOnClickListener {
           NameList()
        }
    }
    
    //选择文件管理器
    private fun intoFileManager() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*" // 无类型限制
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, 1)
    }
    
    //软件回调事件
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                path = FileHelper.getFileAbsolutePath(this, uri)
                if (path != null) {
                    var path2 = path.toString()
                    var path3 = mFileOperation.getFileSuffixName(path2).toLowerCase()
                    if (path3 == "dex") {
                        if (mFileOperation.Exists(path2)) { //文件是否存在
                           if (mFileOperation.CopyFile(path2,global_path + "dex/${mFileOperation.getFileNmae(path2)}")) {
                                addLogs("Dex导入成功，已导入：${mFileOperation.getFileNmae(path2)}")
                                Reset()
                                dexname_edit.setText(mFileOperation.getFileNmae(path2))
                           } else {
                              addLogs("Dex导入失败！")          
                           }
                        } else {
                            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "请选择dex格式的文件！", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    //日志生成
    private fun addLogs(input : String) {
        var text : String = mlogs_text + input + "\n"
        mlogs_text = text
        text_logs.setText(mlogs_text)
    }
    
    //重置
    private fun Reset() {
        dexname_edit.setText("")
        packname_edit.setText("")
        funname_edit.setText("")
    }
    
    //加载名称列表
    private fun NameList() {
        //变量
        var path_list = global_path + "dex" 
        var array_list : Array<String> = arrayOf()
        //转换
        if (mFileOperation.Exists(path_list)) {
            array_list = mFileOperation.FetchSubfileCollection(path_list)
        } else {
            mFileOperation.CreateDirectory(path_list)
            array_list = mFileOperation.FetchSubfileCollection(path_list)
        }
        //初始化
        val popupMenu = PopupMenu(this, dexname_edit, 17)
        popupMenu.gravity = 17
        // 添加菜单项
        for (item_name in array_list) {
            if (mFileOperation.isDirectory(item_name)) {
            } else {
                popupMenu.menu.add(mFileOperation.getFileNmae(item_name.toString()))
            }
        }
        // 设置菜单项点击事件监听器
        popupMenu.setOnMenuItemClickListener { item ->
            val title = item.title
            dexname_edit.setText(title.toString())
            if (mFileOperation.Exists(global_path + mFileOperation.getFilePrefixName(title.toString()) + ".json")) {
                readjson(mFileOperation.getFilePrefixName(title.toString()))
            }
            true
        }
        popupMenu.show()
    }
    
    //生成json
    private fun summon_json(filename : String) {
        val rootObject = JSONObject()
        rootObject.put("pack", packname_edit.getText().toString())
        rootObject.put("fun", funname_edit.getText().toString())
        rootObject.put("static", static_fun)
        mFileOperation.WriteFile(global_path + filename + ".json",rootObject.toString(4))
    }
    
    //读取json
    private fun readjson(filename : String) {
      try {
        var pathsss = mFileOperation.ReadFile(global_path + filename + ".json")
        val rootObject = JSONObject(pathsss)
        val pack: String = rootObject.getString("pack")
        val funValue: String = rootObject.getString("fun")
        val static: Boolean = rootObject.getBoolean("static")
        packname_edit.setText(pack)
        funname_edit.setText(funValue)
        //
        static_fun = static
        if (!static) {
            //关闭静态
            val item: MenuItem = mmMenu.findItem(R.id.menu)
            item.setIcon(R.drawable.ic_compass_off_outline)
            item.setTooltipText("关闭静态方法") 
            addLogs("dex加载器设置：已关闭静态方法")
        } else {
            //启用静态
            val item: MenuItem = mmMenu.findItem(R.id.menu)
            item.setIcon(R.drawable.ic_compass_outline)
            item.setTooltipText("启用静态方法") 
            addLogs("dex加载器设置：已启用静态方法")
        }  
      } catch (e : Exception) {
        addLogs("dex加载json错误：" + e.message)
      }
    }
    
    //加载
    fun loadClassAndInvokeMethod(mContext: Context) {
    
        val dexFilePath = global_path + "dex/" + dexname_edit.getText().toString()

        val dexFile = DexFile(File(dexFilePath))
        val classLoader = DexClassLoader(dexFilePath, filesDir.absolutePath, null, classLoader)

        val className = packname_edit.getText().toString()
        val methodName = funname_edit.getText().toString()
        
        try {
            //判断是否为静态
            if (static_fun) {
                val clazz = classLoader.loadClass(className)
                val method = clazz.getDeclaredMethod(methodName)
                method.isAccessible = true
                val returnType = method.returnType
                val hasReturnValue = returnType != Void.TYPE
                if (hasReturnValue) {
                    val result = method.invoke(null) as String
                    addLogs("dex加载器日志：" + result)
                } else {
                    method.invoke(null)
                    addLogs("${methodName}方法执行完成")
                }

            } else {
                val clazz = classLoader.loadClass(className)
                val method = clazz.getDeclaredMethod(methodName)
                method.isAccessible = true
                val returnType = method.returnType
                val hasReturnValue = returnType != Void.TYPE
                if (hasReturnValue) {
                    val instance = clazz.newInstance()
                    val result = method.invoke(instance) as String
                    addLogs("dex加载器日志：" + result)
                } else {
                    val instance = clazz.newInstance()
                    method.invoke(instance)
                    addLogs("${methodName}方法执行完成")
                }

            }
        
        } catch (e: InvocationTargetException) {
            // 捕获 InvocationTargetException 异常
            addLogs("dex加载器错误：" + e.message)
            addLogs("dex加载器堆栈错误：" + e.printStackTrace())
            e.printStackTrace()
        } catch (e: Exception) {
            // 捕获其他异常
            addLogs("dex加载器错误：" + e.message)
            addLogs("dex加载器堆栈错误：" + e.printStackTrace())
            e.printStackTrace()
        }
    }
    
}    
