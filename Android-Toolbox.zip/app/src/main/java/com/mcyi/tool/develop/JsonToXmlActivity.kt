package com.mcyi.tool.develop

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
//widget
import android.view.View
import android.widget.Toast
import android.widget.ArrayAdapter
import android.widget.AdapterView
import androidx.appcompat.widget.Toolbar
import android.widget.LinearLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.MaterialAutoCompleteTextView
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//App
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
//
import fr.arnaudguyon.xmltojsonlib.XmlToJson
import fr.arnaudguyon.xmltojsonlib.JsonToXml

public class JsonToXmlActivity : AppCompatActivity() {

    //控件声明
    private lateinit var input_edit : TextInputEditText
    private lateinit var output_edit : TextInputEditText
    private lateinit var select_action : MaterialAutoCompleteTextView
    private lateinit var start_run : LinearLayout
    //USE App
    private var mViewComponent : ViewComponent = ViewComponent()
    //基础配置
    private var selectedIndex : Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_develop_jsontoxml)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "Json与Xml互转"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        Init()
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    private fun Init() {
        //给控件初始化
        select_action = findViewById(R.id.select_action)
        input_edit = findViewById<TextInputEditText>(R.id.input_edit)
        output_edit = findViewById<TextInputEditText>(R.id.output_edit)
        start_run = findViewById<LinearLayout>(R.id.start_run)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,start_run)
        //
        SelectAction()
        ClickListener()
    }
    
     //选择操作
    private fun SelectAction() {
        //设置列表
        val options = listOf("Json到Xml","Xml到Json") // 替换为实际的选项列表
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        select_action.setAdapter(adapter)
        select_action.setOnClickListener {
            select_action.showDropDown()
        }
        //项目被点击
        select_action.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            selectedIndex = position
        }
    }
    
     //监听器
    private fun ClickListener() {
        //开始操作
        start_run.setOnClickListener {
           if (input_edit.getText().toString() == "") {
                Toast.makeText(this, "输入编辑框不能为空！", Toast.LENGTH_SHORT).show()
           } else {
                if (selectedIndex >= 0) {
                   Run()
                } else {
                    Toast.makeText(this, "请选择操作！", Toast.LENGTH_SHORT).show()
                }
           }
        }
    }
    
    //开始执行
    private fun Run() {
        if (selectedIndex == 0) {
            try {
                var output_text = jsonToXml(input_edit.text.toString())
                output_edit.setText(output_text)
            } catch (e : Exception) {
                Toast.makeText(this, "错误：$e.getMessage()", Toast.LENGTH_SHORT).show()
            }
        } else if(selectedIndex == 1) {
            try {
                var output_text = xmlToJson(input_edit.text.toString())
                output_edit.setText(output_text)
            } catch (e : Exception) {
                Toast.makeText(this, "错误：$e.getMessage()", Toast.LENGTH_SHORT).show()
            }
        } else {
        
        }
    }
    
    //转换
    fun jsonToXml(jsonContent: String): String {
        val jsonToXml = JsonToXml.Builder(jsonContent).build()
        return jsonToXml.toString()
    }
    fun xmlToJson(xmlContent: String): String {
        val xmlToJson = XmlToJson.Builder(xmlContent).build()
        return xmlToJson.toString()
    }
    
}