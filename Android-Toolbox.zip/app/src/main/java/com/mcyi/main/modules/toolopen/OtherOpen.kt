package com.mcyi.main.modules.toolopen

//基础库
import android.content.Context
import android.content.Intent
//工具活动
import com.mcyi.tool.other.ColorPickerActivity

public class OtherOpen(private val mContext: Context) {

    public fun Open(index : Int) {
        when (index) {
            //颜色选择器
            0 -> {
                val intent = Intent(mContext, ColorPickerActivity::class.java)
                mContext.startActivity(intent)
            }
            else -> {}
        }
    }


}