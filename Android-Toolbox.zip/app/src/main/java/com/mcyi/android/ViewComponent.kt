package com.mcyi.android

import android.content.*
import android.content.res.*
import android.view.*
import android.util.TypedValue

public class ViewComponent {
    
    //水波纹效果
    fun WaterRippleEffect(context : Context,mView : View) {
        val theme: Resources.Theme = context.theme
        val typedValue = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true)
        val attribute = intArrayOf(android.R.attr.selectableItemBackground)
        val typedArray: TypedArray = theme.obtainStyledAttributes(typedValue.resourceId, attribute)
        mView.foreground = typedArray.getDrawable(0)
    }
    
}
