package com.mcyi.main.setting;

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Context
//widget
import android.view.View
import android.widget.Toast
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.appcompat.widget.Toolbar
import android.widget.ListView
import android.widget.Adapter
import android.widget.TextView
import android.view.LayoutInflater
import android.widget.AbsListView
import java.util.ArrayList
import android.view.ViewGroup
import android.widget.ImageView
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//json
import org.json.JSONArray
import org.json.JSONObject
//App
import com.mcyi.main.main.Path
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool2.FileOperation
import com.mcyi.android.tool2.PictureOperation

public class SettingActivity : AppCompatActivity() {

    //List
    private lateinit var mAdapter: ArrayAdapter<String>
    private lateinit var mItems: Array<String>

    //App
    private lateinit var mPath : Path
    private var mViewComponent : ViewComponent = ViewComponent()
    private var mFileOperation : FileOperation = FileOperation()
    private var mPictureOperation : PictureOperation? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_main_setting)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "设置"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //初始化
        mPictureOperation = PictureOperation(this)
        Conversion()
        
    }
    
     //工具栏
     /*
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu2, menu)
        Toolbar(menu)
        return true
    }
    */
    
    //Toolbar
    private fun Toolbar(menu : Menu) {
        /*
        //导入
        val item: MenuItem = menu.findItem(R.id.menu)
        item.setIcon(R.drawable.ic_compass_outline)
        item.setTooltipText("请用静态方法")
        */
    }
    
     //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
            /*
            //选择文件
            R.id.menu -> {

            }
            */
        }
        return super.onOptionsItemSelected(item)
    }
    
    //转换
    private fun Conversion() {
        //初始化
        val list = ArrayList<String>()
        list.clear()
        //读取 循环
        var json_content : String = mFileOperation.ReadResourceFile(this,"data/setting.json")
        val jsonArray = JSONArray(json_content)
        for (i in 0 until jsonArray.length()) {
            val jsonObject = jsonArray.getJSONObject(i)
            list.add(jsonObject.toString())
        }
        //转换
        mItems = list.toTypedArray()
        List()
    }
    
    //列表
    public fun List() {
        //
        val mListView: ListView = findViewById<ListView>(R.id.setting_list)
        mListView.setVerticalScrollBarEnabled(false)
        mListView.setDividerHeight(0)
        //创建适配器
        mAdapter = ArrayAdapter(this, R.layout.list_setting_main, mItems)
        //设置适配器
        mListView.adapter = mAdapter
        //刷新适配器
        mAdapter.notifyDataSetChanged()
        //自定义适配器
        class CustomAdapter(context: Context, items: Array<String>) : ArrayAdapter<String>(context, R.layout.list_setting_main, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                var view = convertView
                if (view == null) {
                    view = LayoutInflater.from(context).inflate(R.layout.list_setting_main, parent, false)
                }
                var text_string = mItems[position]
                var jsonObject = JSONObject(text_string)
                var icon_name = jsonObject.getString("icon")
                var title_name = jsonObject.getString("title")
                var describe_name = jsonObject.getString("describe")
                //设置水波纹
                val button = view!!.findViewById<LinearLayout>(R.id.button)
                mViewComponent.WaterRippleEffect(context,button)
                //设置图标
                val pictureOperation = mPictureOperation
                if (pictureOperation != null) {
                    if (icon_name == "") {
                    } else {
                        val mImageView = view!!.findViewById<ImageView>(R.id.icon_name)
                        pictureOperation.setAssetsImage(mImageView,"image/setting/${icon_name}")
                    }
                }
                //设置名称
                val title_nameView = view!!.findViewById<TextView>(R.id.title_name)
                title_nameView.text = title_name
                //设置描述
                val describe_nameView = view!!.findViewById<TextView>(R.id.describe_name)
                describe_nameView.text = describe_name
                return view
            }
        }
        //使用自定义适配器
        val customAdapter = CustomAdapter(this, mItems)
        mListView.adapter = customAdapter
        //列表被点击
        mListView.setOnItemClickListener { _, _, position, _ ->
            var text_string : String = mItems[position]
            val jsonObject = JSONObject(text_string)
            
        }
        //列表被长按
        mListView.setOnItemLongClickListener { _, _, position, _ ->
            var text_string : String = mItems[position]
            
            true
        }
    }
    
}    