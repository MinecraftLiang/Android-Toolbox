package com.mcyi.editor.TextEditor

import android.widget.EditText
import android.text.Editable

import com.mcyi.library.editor.PerformEdit

class ToolbarModule(private val mEditText: EditText) {

    private var mPerformEdit: PerformEdit

    // 初始化
    init {
        mPerformEdit = object : PerformEdit(mEditText) {
            override fun onTextChanged(s: Editable) {
                //文本发生改变,可以是用户输入或者是EditText.setText触发.(setDefaultText的时候不会回调)
                super.onTextChanged(s)
            }
        }
        //初始值
        mPerformEdit.setDefaultText("")
    }
    
    // 设置
    public fun setText(text : String) {
        mPerformEdit.setDefaultText(text)
    }

    // 撤销
    public fun undo() {
        mPerformEdit.undo()
    }

    // 重做
    public fun redo() {
        mPerformEdit.redo()
    }
    
    // 清除记录
    public fun clearHistory() {
        mPerformEdit.clearHistory()
    }
    
}