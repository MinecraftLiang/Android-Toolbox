package com.mcyi.main.modules.pager

//
import com.mcyi.main.R
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.Button

//活动
import com.mcyi.main.setting.SettingActivity


public class Centre(private val mContext: Context,private val mView: View) {

    init {
    
    }
    
    //
    public fun Listener() {
        val setting = mView.findViewById<Button>(R.id.setting)
        setting.setOnClickListener {
            val intent = Intent(mContext, SettingActivity::class.java)
            mContext.startActivity(intent)
        }
    }

}
