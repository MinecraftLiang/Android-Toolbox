package com.mcyi.tool.text

//默认库
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mcyi.main.R
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//
import android.view.View
import android.widget.Toast
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.LinearLayout
import androidx.appcompat.widget.Toolbar
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.MaterialAutoCompleteTextView

//Android App
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool.EncryptionOperation
import com.mcyi.android.tool.DecryptionOperation
import com.mcyi.android.tool.CodingOperation
import com.mcyi.android.tool.ConversionOperation

public class TextOperateActivity : AppCompatActivity() {

    //声明控件属性
    private lateinit var input_edit : TextInputEditText
    private lateinit var encoding_edit : TextInputEditText
    private lateinit var select_action : MaterialAutoCompleteTextView
    private lateinit var password_edit : TextInputEditText
    private lateinit var output_edit : TextInputEditText
    private lateinit var start_run : LinearLayout
    
    //
    private var mViewComponent : ViewComponent = ViewComponent()
    private var mEncryptionOperation : EncryptionOperation = EncryptionOperation()
    private var mDecryptionOperation : DecryptionOperation = DecryptionOperation()
    private var mCodingOperation : CodingOperation = CodingOperation()
    private var mConversionOperation : ConversionOperation = ConversionOperation()
    
    //
    private var selectedIndex : Int = -1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_text_text_operate)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "文本操作"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        Init()
    }
    
    private fun Init() {
        //控件属性
        input_edit = findViewById<TextInputEditText>(R.id.input_edit)
        select_action = findViewById(R.id.select_action)
        encoding_edit = findViewById<TextInputEditText>(R.id.encoding_edit)
        password_edit = findViewById<TextInputEditText>(R.id.password_edit)
        output_edit = findViewById<TextInputEditText>(R.id.output_edit)
        start_run = findViewById<LinearLayout>(R.id.start_run)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,start_run)
        //加载监听器
        ClickListener()
        SelectAction()
        //显示隐藏布局
        Hide_Show(true)
        Hide_Show2(false)
    }
    
    //监听器
    private fun ClickListener() {
        //开始操作
        start_run.setOnClickListener {
           if (input_edit.getText().toString() == "") {
                Toast.makeText(this, "输入编辑框不能为空！", Toast.LENGTH_SHORT).show()
           } else {
                if (selectedIndex >= 0) {
                   Run(selectedIndex) 
                } else {
                    Toast.makeText(this, "请选择操作！", Toast.LENGTH_SHORT).show()
                }
           }
        }
    }
    
    //选择操作
    private fun SelectAction() {
        //设置列表
        val options1 = listOf("MD5加密","CRC32加密","SHA加密","RSA加密","RSA解密","AES加密","AES解密","RC4加密","RC4解密") // 替换为实际的选项列表
        val options2 = listOf("URL编码","URL解码","UCS2编码","UCS2解码","Base64编码","Base64解码")
        val options3 = listOf("文本转HEX","HEX转文本","中文转Unicode","Unicode转中文")
        val options = options1 + options2 + options3
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        select_action.setAdapter(adapter)
        select_action.setOnClickListener {
            select_action.showDropDown()
        }
        //项目被点击
        select_action.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            selectedIndex = position
            //用来隐藏或者显示布局
            when (selectedIndex) {
                0 -> {
                    Hide_Show(true)
                    Hide_Show2(false)
                }
                1 -> {
                    Hide_Show(false)
                    Hide_Show2(false)
                }
                2 -> {
                    Hide_Show(true)
                    Hide_Show2(false)
                }
                in 3..4 -> {
                    Hide_Show(false)
                    Hide_Show2(false)
                }
                in 5..6 -> {
                    password_edit.setHint("       长度必须等于16")
                    Hide_Show(false)
                    Hide_Show2(true)
                }
                in 7..8 -> {
                    password_edit.setHint("       长度必须大于1")
                    Hide_Show(false)
                    Hide_Show2(true)
                }
                in 9..10 -> {
                    password_edit.setHint("")
                    Hide_Show(true)
                    Hide_Show2(false)
                }
                in 11..12 -> {
                    password_edit.setHint("")
                    Hide_Show(false)
                    Hide_Show2(false)
                }
                in 13..14 -> {
                    password_edit.setHint("")
                    Hide_Show(true)
                    Hide_Show2(false)
                }
                in 15..16 -> {
                    password_edit.setHint("")
                    Hide_Show(false)
                    Hide_Show2(false)
                }
                in 17..18 -> {
                    password_edit.setHint("")
                    Hide_Show(false)
                    Hide_Show2(false)
                }
            }
        }
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //
            android.R.id.home -> {
               finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //编码布局是否隐藏显示
    private fun Hide_Show(bis : Boolean) {
        val layout = findViewById<TextInputLayout>(R.id.encoding_edit_layout)
        if (bis) {
            layout.visibility = View.VISIBLE
        } else {
            layout.visibility = View.GONE
        }
    }
    
    //密码布局是否隐藏显示
    private fun Hide_Show2(bis : Boolean) {
        val mpassword_edit_layout = findViewById<TextInputLayout>(R.id.password_edit_layout)
        if (bis) {
            mpassword_edit_layout.visibility = View.VISIBLE
        } else {
            password_edit.setHint("")
            mpassword_edit_layout.visibility = View.GONE
        }
    }
    
    //执行
    private fun Run(ID : Int) {
        var encoding = if (encoding_edit.text.toString() == "") "UTF-8" else encoding_edit.text.toString()
        when (ID) {
            //MD5加密
            0 -> {
                var output_text = mEncryptionOperation.MD5Encryption(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //CRC32加密
            1 -> {
                var output_text = mEncryptionOperation.CRC32Encryption(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //SHA加密
            2 -> {
                var output_text = mEncryptionOperation.SHAEncryption(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //RSA加密
            3 -> {
                var output_text = mEncryptionOperation.RSAEncryption(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //RSA解密
            4 -> {
                var output_text = mDecryptionOperation.RSADecryption(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //AES加密
            5 -> {
                var output_text = mEncryptionOperation.AESEncryption(input_edit.text.toString(),password_edit.text.toString())
                output_edit.setText(output_text)
            }
            //AES解密
            6 -> {
                var output_text = mDecryptionOperation.AESDecryption(input_edit.text.toString(),password_edit.text.toString())
                output_edit.setText(output_text)
            }
            //RC4加密
            7 -> {
                var output_text = mEncryptionOperation.RC4Encryption(input_edit.text.toString(),password_edit.text.toString())
                output_edit.setText(output_text)
            }
            //RC4解密
            8 -> {
                var output_text = mDecryptionOperation.RC4Decryption(input_edit.text.toString(),password_edit.text.toString())
                output_edit.setText(output_text)
            }
            //URL编码
            9 -> {
                var output_text = mCodingOperation.URLEncoding(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //URL解码
            10 -> {
                var output_text = mCodingOperation.URLDecoding(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //UCS2编码
            11 -> {
                var output_text = mCodingOperation.UCS2Encoding(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //UCS2解码
            12 -> {
                var output_text = mCodingOperation.UCS2Decoding(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //Base64编码
            13 -> {
                var output_text = mCodingOperation.Base64Encoding(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //Base64解码
            14 -> {
                var output_text = mCodingOperation.Base64Decoding(input_edit.text.toString(),encoding)
                output_edit.setText(output_text)
            }
            //文本转HEX
            15 -> {
                var output_text = mConversionOperation.StringtoInt(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //HEX转文本
            16 -> {
                var output_text = mConversionOperation.InttoString(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //中文转Unicode
            17 -> {
                var output_text = mConversionOperation.ChinesetoUnicode(input_edit.text.toString())
                output_edit.setText(output_text)
            }
            //Unicode转中文
            18 -> {
                var output_text = mConversionOperation.UnicodetoChinese(input_edit.text.toString())
                output_edit.setText(output_text)
            }
        }
    }
    
}
