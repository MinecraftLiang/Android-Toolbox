package com.mcyi.tool.text

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Context
//
import java.util.ArrayList
//widget
import android.view.View
import android.widget.Toast
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.appcompat.widget.Toolbar
import android.widget.ListView
import android.widget.Adapter
import android.widget.TextView
import android.view.LayoutInflater
import android.widget.AbsListView
import android.view.ViewGroup
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//App
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool.SystemOperation

public class UUIDActivity : AppCompatActivity() {

    //List
    private lateinit var mAdapter: ArrayAdapter<String>
    private lateinit var mItems: Array<String>
    
    //
    private var Capitalize : Boolean = false  //大写
    private var Separator : Boolean = true //分隔符
    private var Number : Int = 50 //数量
    

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_text_uuid)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "UUID"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        Run()
    }
    
    //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu, menu)
        Toolbar(menu)
        return true
    }
    
    //Toolbar
    private fun Toolbar(menu : Menu) {
        val item: MenuItem = menu.findItem(R.id.menu)
        item.setIcon(R.drawable.refresh)
        item.setTooltipText("刷新")
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //
            android.R.id.home -> {
               finish()
            }
            R.id.menu -> {
                Run()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //开始
    public fun Run() {
        //初始化
        val list = ArrayList<String>()
        list.clear()
        var i = 0
        //
        while (i < Number) {
            var Str1 : String = if (Capitalize) getUUID().toUpperCase() else getUUID()
            var Str2 : String = if (Separator) Str1 else Str1.replace("-","")
            list.add(Str2)
            i++
        }
        //
        mItems = list.toTypedArray()
        List()
    }
    
    //列表
    public fun List() {
        //
        val mListView: ListView = findViewById<ListView>(R.id.listview)
        mListView.setVerticalScrollBarEnabled(false)
        mListView.setDividerHeight(0)
        //创建适配器
        mAdapter = ArrayAdapter(this, R.layout.list_tool_big, mItems)
        //设置适配器
        mListView.adapter = mAdapter
        //刷新适配器
        mAdapter.notifyDataSetChanged()
        //自定义适配器
        class CustomAdapter(context: Context, items: Array<String>) : ArrayAdapter<String>(context, R.layout.list_tool_big, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                var view = convertView
                if (view == null) {
                    view = LayoutInflater.from(context).inflate(R.layout.list_tool_big, parent, false)
                }
                var text_string = mItems[position]
                //设置水波纹
                val mViewComponent : ViewComponent = ViewComponent()
                val button = view!!.findViewById<LinearLayout>(R.id.button)
                mViewComponent.WaterRippleEffect(context,button)
                //获取名称
                val textView = view!!.findViewById<TextView>(R.id.title_name)
                textView.text = text_string
                return view
            }
        }
        //使用自定义适配器
        val customAdapter = CustomAdapter(this, mItems)
        mListView.adapter = customAdapter
        //列表被点击
        mListView.setOnItemClickListener { _, _, position, _ ->
            var text_string : String = mItems[position]
            SystemOperation.setClipboardText(this,text_string)
            Toast.makeText(this, "复制成功！", Toast.LENGTH_SHORT).show()
        }
        //列表被长按
        mListView.setOnItemLongClickListener { _, _, position, _ ->
            var text_string : String = mItems[position]
            
            true
        }
    }
    
    //获取随机UUID
    private fun getUUID() : String {
        return java.util.UUID.randomUUID().toString()
    }
    
}
