package com.mcyi.editor.TextEditor

import android.widget.EditText
import android.content.Context
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface
import android.util.TypedValue
import android.view.ViewGroup
import android.text.TextWatcher
import android.text.Editable

import com.mcyi.android.ViewComponent
import com.mcyi.android.tool.PixelOperation


public class ComplementModules(private val mContext: Context,
            private val mEditText: EditText,
            private val mLinearLayout: LinearLayout) {
    
    //是否启用自动补全
    var Automatic_Completion_Option : Boolean = false
    
    var list : MutableList<String> = mutableListOf()
    var complete_list : MutableList<String> = mutableListOf("if","else","for","while")
    
    var Text : String = ""
    var import_text : String = ""
    
    //初始化
    init {
        Listener()
    }
    
    //过滤
    public fun Filtration(iport : String) {
        list.clear()
        for (item in complete_list) {
            if (item.contains(iport)) {
               list.add(item.toString()) 
            }
        }
        List()
    }
    
    //列表
    public fun List() {
        val mPixelOperation = PixelOperation()
        val mViewComponent = ViewComponent()
        mLinearLayout.removeAllViews()
        for (item in list) {
            val mTextView = TextView(mContext)
            mTextView.setText(item)
            mTextView.setTextColor(-16777216)
            mTextView.setGravity(17)
            mTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            mTextView.setBackgroundColor(-526087)
            // 设置宽度和高度
            val layoutParams = ViewGroup.LayoutParams(
                mPixelOperation.DPtoPX(mContext,60), // 设置宽度为40dp
                mPixelOperation.DPtoPX(mContext,35)  // 设置高度为40dp
            )
            mTextView.layoutParams = layoutParams
            //设置水波纹
            mViewComponent.WaterRippleEffect(mContext,mTextView)
            mLinearLayout.addView(mTextView)
            //设置监听器
            mTextView.setOnClickListener {
                Insert_Text(mTextView.getText().toString())
                mLinearLayout.removeAllViews()
            }
        }
    }
    
    //监听器
    public fun Listener() {
        mEditText.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                // 不需要实现
            }
            override fun onTextChanged(charSequence: CharSequence, start: Int, before: Int, count: Int) {
              // 获取最近输入的字符
              if (Automatic_Completion_Option) {
                val recentText: String = charSequence.toString()
                val cursorPosition: Int = mEditText.selectionStart
                if (cursorPosition in 1..recentText.length) {
                    val previousPosition: Int = cursorPosition - 1
                    if (previousPosition >= 0) {
                        val previousChar: String = recentText[previousPosition].toString()
                        if (recentText[previousPosition] == ' ') {
                            // 空格
                            Text = ""
                            import_text = Text
                            list = mutableListOf()
                            mLinearLayout.removeAllViews()
                        } else if (recentText[previousPosition] == '\n') {
                            // 换行
                            Text = ""
                            import_text = Text
                            list = mutableListOf()
                            mLinearLayout.removeAllViews()
                        } else {
                            // 其他情况
                            Text = Text + previousChar
                            import_text = Text
                            if (Automatic_Completion_Option) {
                                Filtration(Text)
                            }
                        }
                    }
                }
              }
            }
        	override fun afterTextChanged(editable: Editable) {
            // 不需要实现
            }
        })
        //按键接听
        mEditText.setOnKeyListener { _, keyCode, _ ->
            when (keyCode) {
                67 -> {
                 Text = ""
                 import_text = Text
                 list = mutableListOf()
                 mLinearLayout.removeAllViews()   
                }
            }
            false // 返回 true 表示已经处理了按键事件
        }
    }
    
    //设置
    public fun Completion(iss : Boolean) {
        Automatic_Completion_Option = iss
        if (Automatic_Completion_Option) {
            
        } else {
            
        }
    }
    
    //插入文本
    private fun Insert_Text(tex : String) {
        val position = mEditText.selectionStart // 获取光标的位置
        val editable = mEditText.text
        val import_size: Int = import_text.length
        val start = maxOf(position - import_size, 0) // 确保不超出字符串范围
        editable.delete(start, position)
        val position2 = mEditText.selectionStart 
        editable.insert(position2, tex) // 在光标位置插入文本
    }
    
    
    
}
