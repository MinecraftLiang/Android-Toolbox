package com.mcyi.tool.mcpe

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Intent
import android.app.Activity
import android.net.Uri
//widget
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import android.widget.LinearLayout
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//App
import com.mcyi.android.utils.FileHelper
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool2.FileOperation
import com.mcyi.android.tool2.BitmapOperation
//3D 2D
import dev.storeforminecraft.skinviewandroid.library.twodimension.ui.FlatSkinView
import dev.storeforminecraft.skinviewandroid.library.threedimension.ui.SkinView3DSurfaceView
//Bitmap IO
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.IOException
import java.io.InputStream

public class SkinPreviewActivity : AppCompatActivity() {

    //APP
    private val mFileOperation = FileOperation()
    private val mBitmapOperation = BitmapOperation(this)
    //
    private lateinit var gLView: SkinView3DSurfaceView

    //
    private var View2D : Boolean = true
    var path: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_mcpe_skinpreview)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "皮肤预览器"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        
        Init()
    }
    
     //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu2, menu)
        Toolbar(menu)
        return true
    }
    
    //初始化
    private fun Init() {
        //2D
        val flatskinview: FlatSkinView = findViewById<FlatSkinView>(R.id.flatskinview)
        flatskinview.visibility = View.VISIBLE
        //3D
        View3D()
        gLView.visibility = View.GONE
    }
    
    //加载3D
    private fun View3D() {
        val layout: LinearLayout = findViewById<LinearLayout>(R.id.layout)
    
        gLView = SkinView3DSurfaceView(this)
        
        val `is`: InputStream = resources
            .openRawResource(R.raw.steve)
        val bitmap: Bitmap = try {
            BitmapFactory.decodeStream(`is`)
        } finally {
            try {
                `is`.close()
            } catch (e: IOException) {
            }
        }
        gLView.render(bitmap)
        
        layout.addView(gLView)
    }
    
    //Toolbar
    private fun Toolbar(menu : Menu) {
        //导入
        val item: MenuItem = menu.findItem(R.id.menu2)
        item.setIcon(R.drawable.file_import)
        item.setTooltipText("导入皮肤png")
        //切换
        val item2: MenuItem = menu.findItem(R.id.menu)
        item2.setIcon(R.drawable.v3d_off)
        item2.setTooltipText("2D View")
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val flatskinview: FlatSkinView = findViewById<FlatSkinView>(R.id.flatskinview)
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
            //导入文件
            R.id.menu -> {
              if (View2D) {
                    View2D = false
                    item.setIcon(R.drawable.v3d)
                    item.setTooltipText("3D View") 
                    flatskinview.visibility = View.GONE
                    gLView.visibility = View.VISIBLE
                } else {
                    View2D = true
                    item.setIcon(R.drawable.v3d_off)
                    item.setTooltipText("2D View") 
                    flatskinview.visibility = View.VISIBLE
                    gLView.visibility = View.GONE
                }  
            }
            R.id.menu2 -> {
              intoFileManager()  
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //选择文件管理器
    private fun intoFileManager() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*" // 无类型限制
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, 1)
    }
    
    //软件回调事件
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                path = FileHelper.getFileAbsolutePath(this, uri)
                if (path != null) {
                    var path2 = path.toString()
                    var path3 = mFileOperation.getFileSuffixName(path2).toLowerCase()
                    if (path3 == "png") {
                        if (mFileOperation.Exists(path2)) { //文件是否存在
                           LoadSkin(path2) 
                        } else {
                            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "请选择png格式的图片！", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    //加载皮肤
    private fun LoadSkin(mPath : String) {
        //初始化
        var mBitmap : Bitmap = mBitmapOperation.getBitmapFromInternalStorage(mPath)
        val layout: LinearLayout = findViewById<LinearLayout>(R.id.layout)
        //2D
        val flatskinview: FlatSkinView = findViewById<FlatSkinView>(R.id.flatskinview)
        flatskinview.renderSkin(mBitmap)
        //3D
        layout.removeView(gLView)
        gLView = SkinView3DSurfaceView(this)
        try {
        gLView.render(mBitmap)
            } catch (e: IOException) {
        }
        layout.addView(gLView)
        Display(gLView)
    }
    
    //是否显示
    private fun Display(mView : View) {
        if (View2D) {
            mView.visibility = View.GONE
        } else {
            mView.visibility = View.VISIBLE
        }
    }
    
}
