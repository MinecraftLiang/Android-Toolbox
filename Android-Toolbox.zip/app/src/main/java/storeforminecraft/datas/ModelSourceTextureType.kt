package dev.storeforminecraft.skinviewandroid.library.datas

enum class ModelSourceTextureType {
    RATIO_2_1,
    RATIO_1_1,
    RATIO_1_1_SLIM,
    UNKNOWN
}