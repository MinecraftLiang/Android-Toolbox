package com.mcyi.editor.TextEditor

//布局：list_editor_file

import com.mcyi.main.R
import android.view.View
import android.content.Context
import android.view.ViewGroup
import android.widget.ListView
import android.widget.TextView
import android.view.LayoutInflater
import android.widget.AbsListView
import android.widget.ArrayAdapter

import com.mcyi.android.tool2.FileOperation

public class FileModules(private val mContext: Context,
        private val mFileListView: ListView,
        private val mFilePath: String) {

    private var mListeners: OnFileListener? = null
    
    //List
    private lateinit var mAdapter: ArrayAdapter<String>
    private lateinit var mItems: Array<String>
    
    //App
    private var mFileOperation: FileOperation = FileOperation()
    
    //初始化
    init {
        //获取数组
        val subfiles = mFileOperation.FetchSubfileCollection(mFilePath)
        mItems = subfiles
        //
        FileList()
    }
    
    //文件
    private fun FileList() {
        //创建适配器
        mAdapter = ArrayAdapter(mContext, R.layout.list_editor_file, mItems)
        //设置适配器
        mFileListView.adapter = mAdapter
        //刷新适配器
        mAdapter.notifyDataSetChanged()
        //自定义适配器
        class CustomAdapter(context: Context, items: Array<String>) : ArrayAdapter<String>(context, R.layout.list_editor_file, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                var view = convertView
                if (view == null) {
                    view = LayoutInflater.from(context).inflate(R.layout.list_editor_file, parent, false)
                }
                var file_path = mItems[position]
                //获取名称
                val textView: TextView = view!!.findViewById(R.id.file_name)
                textView.text = mFileOperation.getFileNmae(file_path)
                //获取时间
                val textView2: TextView = view!!.findViewById(R.id.file_describe)
                textView2.text = mFileOperation.GetModifiedTime(file_path)
                return view
            }
        }
        //使用自定义适配器
        val customAdapter = CustomAdapter(mContext, mItems)
        mFileListView.adapter = customAdapter
        //列表被点击
        mFileListView.setOnItemClickListener { _, _, position, _ ->
            var Path : String = mItems[position]
            mListeners?.onSelected(Path)
        }
        //列表被长按
        mFileListView.setOnItemLongClickListener { _, _, position, _ ->
            var Path : String = mItems[position]
            
            true
        }
    }
    
    //创建文件
    var i = 0
    public fun addFile() {
        //写出文件
        i = mItems.size
        mFileOperation.WriteFile(mFilePath + "/" + i.toString() + ".txt","")
        //刷新列表
        val subfiles = mFileOperation.FetchSubfileCollection(mFilePath)
        mItems = subfiles
        FileList()
        //计数
        i++
    }
    
    fun setOnFileListener(listener: OnFileListener) {
        mListeners = listener
    }    
    
    interface OnFileListener {
        fun onSelected(path: String)
    }
    
}
