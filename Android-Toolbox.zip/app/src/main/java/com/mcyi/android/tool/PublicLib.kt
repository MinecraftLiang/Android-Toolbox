package com.mcyi.android.tool

import java.nio.charset.Charset

public class PublicLib {

    //RC4Base
    public fun RC4Base(input: ByteArray, password: String): ByteArray {
        var x = 0
        var y = 0
        val key = initKey(password)
    
        val result = ByteArray(input.size)
        for (i in input.indices) {
            x = (x + 1) and 0xFF
            y = (key[x].toInt() and 0xFF) + y and 0xFF
            val tmp = key[x]
            key[x] = key[y]
            key[y] = tmp
            val xorIndex = (key[x].toInt() and 0xFF) + (key[y].toInt() and 0xFF) and 0xFF
            result[i] = (input[i].toInt() xor key[xorIndex].toInt()).toByte()
        }
        return result
    }
    
    //initKey
    public fun initKey(password: String, encoding: Charset = Charsets.UTF_8): ByteArray {
        try {
            val bKey = password.toByteArray(encoding)
            val state = ByteArray(256)
    
            for (i in 0 until 256) {
                state[i] = i.toByte()
            }
    
            var index1 = 0
            var index2 = 0
            if (bKey.isEmpty()) {
                return byteArrayOf()
            }
            for (i in 0 until 256) {
            index2 = (bKey[index1].toInt() and 0xFF) + (state[i].toInt() and 0xFF) + index2 and 0xFF
                val tmp = state[i]
                state[i] = state[index2]
                state[index2] = tmp
                index1 = (index1 + 1) % bKey.size
            }
            return state
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return byteArrayOf()
    }
    
    //HexString2Bytes
    public fun HexString2Bytes(content: String, encoding: Charset = Charsets.UTF_8): ByteArray {
        try {
            val size = content.length
            val ret = ByteArray(size / 2)
            val tmp = content.toByteArray(encoding)
            for (i in 0 until size / 2) {
                ret[i] = uniteBytes(tmp[i * 2], tmp[i * 2 + 1])
            }
            return ret
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return byteArrayOf()
    }
    
    //uniteBytes
    public fun uniteBytes(byte1: Byte, byte2: Byte): Byte {
        val _b0 = byte1.toInt().shl(4).toChar()
        val _b1 = byte2.toInt().toChar()
        val ret = _b0.toInt() xor _b1.toInt()
        return ret.toByte()
    }


}
