package com.mcyi.main.main

import android.content.Context

public class Path(private val mContext: Context) {

    //变量
    var path : String = ""
    
    init {
        path = mContext.getExternalFilesDir(null)!!.absolutePath
    }
    
    //获取路径
    public fun getMainPath() : String {
        return path + "/"
    }
    
    //获取工具路径
    public fun getToolboxPath() : String {
        return path + "/toolbox/"
    }
    
    
}