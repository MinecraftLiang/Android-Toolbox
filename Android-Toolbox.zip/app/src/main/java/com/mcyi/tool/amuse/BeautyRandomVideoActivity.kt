package com.mcyi.tool.amuse

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
//widget
import android.view.View
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.widget.Toolbar
import com.google.android.material.slider.Slider
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.cardview.widget.CardView
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//json
import org.json.JSONArray
import org.json.JSONObject
//网络
import android.net.Uri
//App
import com.mcyi.main.main.Path
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool2.FileOperation

public class BeautyRandomVideoActivity : AppCompatActivity() {

    //控件
    private lateinit var mvideoview : VideoView
    //App
    private lateinit var mPath : Path
    private var mViewComponent : ViewComponent = ViewComponent()
    private var mFileOperation : FileOperation = FileOperation()
    //变量
    private var progress_display_option : Boolean = false
    private var progress_display_option2 : Boolean = false
    private var url_text : String = "https://api.woeo.net/API/api-girl/index.php"
    private var json_is : Boolean = false
    private var json_name = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_amuse_beauty_rvideo)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "随机美女视频"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //控件初始化
        mvideoview = findViewById(R.id.mvideoview)
        //
        APIList()
        ClickListener()
    }
    
     //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu2, menu)
        Toolbar(menu)
        return true
    }
    
     //Toolbar
    private fun Toolbar(menu : Menu) {
        //下载
        val item: MenuItem = menu.findItem(R.id.menu)
        item.setIcon(R.drawable.ic_folder_download)
        item.setTooltipText("下载")
        //
        val item2: MenuItem = menu.findItem(R.id.menu2)
        item2.setIcon(R.drawable.ic_api)
        item2.setTooltipText("切换API")
    }
    
     //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
            //下载
            R.id.menu -> {
                
            }
            //切换
            R.id.menu2 -> {
                val layout2 = findViewById<LinearLayout>(R.id.layout2)
                val layout_asd = findViewById<CardView>(R.id.layout_asd)
                if (progress_display_option2) {
                    progress_display_option2 = false
                    layout2.visibility = View.GONE
                } else {
                    progress_display_option2 = true
                    layout2.visibility = View.VISIBLE
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //加载api列表
    private fun APIList() {
        val list = ArrayList<String>()
        val layout_radiogroup = findViewById<RadioGroup>(R.id.layout_radiogroup)
        var json_content : String = mFileOperation.ReadResourceFile(this,"data/toolbox/amuse/beauty_randomvideo_api.json")
        val jsonArray = JSONArray(json_content)
        for (i in 0 until jsonArray.length()) {
            val jsonObject = jsonArray.getJSONObject(i)
            list.add(jsonObject.toString())
            var name = jsonObject.getString("name")
            var mRadioGroup = RadioButton(this)
            mRadioGroup.setText(name)
            layout_radiogroup.addView(mRadioGroup)
            //监听器
            layout_radiogroup.setOnCheckedChangeListener { group, checkedId ->
                val index = layout_radiogroup.indexOfChild(findViewById(checkedId))
                var jsonObject2 = JSONObject(list[index])
                var url = jsonObject2.getString("url")
                url_text = url
                if (jsonObject2.has("json")) {
                    json_is = false
                    var json_name_js = jsonObject2.getJSONObject("json")
                    var url_name = json_name_js.getString("url_name")
                    json_name = url_name
                }
            }
        }
    }
    
    //监听器
    private fun ClickListener() {
        //进度条
        val layout = findViewById<RelativeLayout>(R.id.layout)
        layout.setOnClickListener {
            val dragbar_view = findViewById<Slider>(R.id.dragbar_view)
            if (progress_display_option) {
                progress_display_option = false
                dragbar_view.visibility = View.GONE
            } else {
                progress_display_option = true
                dragbar_view.visibility = View.VISIBLE
            }
        }
        //下拉刷新
        val mswiperefreshlayout = findViewById<SwipeRefreshLayout>(R.id.mswiperefreshlayout)
        mswiperefreshlayout.setOnRefreshListener {
            Toast.makeText(this, url_text, Toast.LENGTH_SHORT).show()
            RefreshVideo(mswiperefreshlayout)
        }
    }
    
    //加载视频
    private fun Video() {
        
    }
    //刷新视频
    private fun RefreshVideo(mswiperefreshlayout : SwipeRefreshLayout) {
        
        // 在后台线程中执行网络请求
        mvideoview.setVideoURI(Uri.parse(url_text))
        mvideoview.setOnPreparedListener { mediaPlayer ->
            mediaPlayer.start()
            mswiperefreshlayout.setRefreshing(false)
       }
        
    }
    
    fun zaazzw(sssmm : String) {
        throw RuntimeException(sssmm)
    }
    
    
}    