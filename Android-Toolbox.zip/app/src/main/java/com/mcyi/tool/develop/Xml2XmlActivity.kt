package com.mcyi.tool.develop

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Intent
import android.app.Activity
import android.net.Uri
//widget
import android.view.View
import android.widget.Toast
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import android.widget.LinearLayout
import com.google.android.material.textfield.TextInputEditText
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//对话框
import android.content.DialogInterface
import androidx.appcompat.app.AlertDialog
//App
import com.mcyi.main.main.Path
import com.mcyi.android.utils.FileHelper
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool2.FileOperation
//
import com.bigzhao.xml2axml.test.Main

public class Xml2XmlActivity : AppCompatActivity() {

    //控件声明
    private lateinit var input_edit : TextInputEditText
    private lateinit var start_run : LinearLayout
    private lateinit var text_logs : TextView
    //App
    private lateinit var mPath : Path
    private var mViewComponent : ViewComponent = ViewComponent()
    private var mFileOperation : FileOperation = FileOperation()
    //变量
    private var mlogs_text : String = ""
    var path: String? = null
    private var DefaultSelectedIndex : Int = 0
    //设置选项
    private var Process_Single : Boolean = true
    
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_develop_xml2axml)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "Xml编译或反编译"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        Init()
    }
    
    //工具栏
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_system_menu, menu)
        Toolbar(menu)
        return true
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //退出
            android.R.id.home -> {
               finish()
            }
            //选择文件
            R.id.menu -> {
                intoFileManager()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //选择文件管理器
    private fun intoFileManager() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*" // 无类型限制
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, 1)
    }
    
    //软件回调事件
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                path = FileHelper.getFileAbsolutePath(this, uri)
                if (path != null) {
                    var path2 = path.toString()
                    var path3 = mFileOperation.getFileSuffixName(path2).toLowerCase()
                    if (path3 == "xml") {
                        if (mFileOperation.Exists(path2)) { //文件是否存在
                           //提示已选择
                           var filename_path = mFileOperation.getFileNmae(path2)
                           addLogs("文件已选择：" + filename_path)
                        } else {
                            Toast.makeText(this, "文件不存在！", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "请选择xml格式的文件！", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    //Toolbar
    private fun Toolbar(menu : Menu) {
        //导入
        val item: MenuItem = menu.findItem(R.id.menu)
        item.setIcon(R.drawable.file_import)
        item.setTooltipText("导入Xml文件")
    }
    
    private fun Init() {
        //路径初始化
        mPath = Path(this)
        //给控件初始化
        input_edit = findViewById<TextInputEditText>(R.id.input_edit)
        start_run = findViewById<LinearLayout>(R.id.button)
        text_logs = findViewById<TextView>(R.id.text_logs)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,start_run)
        //
        ClickListener()
    }
    
     //监听器
    private fun ClickListener() {
        //开始操作
        start_run.setOnClickListener {
           if (input_edit.getText().toString() == "") {
                Toast.makeText(this, "输入编辑框不能为空！", Toast.LENGTH_SHORT).show()
           } else {
                val nonNullPath = path
               if (nonNullPath != null) {
                    if (mFileOperation.Exists(nonNullPath)) {
                        if (mFileOperation.isDirectory(nonNullPath)) {
                            //文件夹
                            addLogs("请选择文件！")
                        } else {
                            //文件
                            RunDialog()
                        }
                    } else {
                        addLogs("目标文件(夹)不存在！")
                    }                                
                } else {
                    addLogs("你未选择任何文件！")
                }
           }
        }
    }
    
    //日志生成
    private fun addLogs(input : String) {
        var text : String = mlogs_text + input + "\n"
        mlogs_text = text
        text_logs.setText(mlogs_text)
    }
    
    private fun RunDialog() {
        // 创建选项列表
        val options = arrayOf("Xml编译", "Xml反编译")
        // 创建对话框构建器
        val builder = AlertDialog.Builder(this)
        builder.setTitle("操作")
        .setSingleChoiceItems(options, DefaultSelectedIndex) { dialogInterface: DialogInterface, selectedIndex: Int ->
                // 设置值
                DefaultSelectedIndex = selectedIndex
            }
            .setNegativeButton("取消") { dialogInterface: DialogInterface, _: Int ->
                dialogInterface.dismiss()
            }
            .setPositiveButton("确定") { dialogInterface: DialogInterface, _: Int ->
                // 处理"OK"按钮点击事件的逻辑
                RunFile(DefaultSelectedIndex)
                dialogInterface.dismiss()
            }
        // 创建并显示对话框
        val dialog = builder.create()
        dialog.show()
    }
    
    //
    private fun RunFile(type : Int) {
        val nonNullPaths = path
        if (nonNullPaths != null) {
            //变量
            var name = input_edit.getText().toString() 
            var parent_path = mPath.getToolboxPath() + "develop/axml2axml"
            var path_encode_output = parent_path + "/" + name + "_encode_output.xml"
            var path_decode_output = parent_path + "/" + name + "_decode_output.xml"
            //编译
            if (type == 0) {
                var consequence = Main.encode(path,path_encode_output)
                if (consequence == "true") {
                    addLogs("编译成功，位置：$path_encode_output")
                } else {
                    addLogs("编译失败，错误信息：\n: " + consequence)
                }
            } else {
                var consequence = Main.decode(path,path_decode_output)
                if (consequence == "true") {
                    if (mFileOperation.ReadFile(path_decode_output).length >= 1) {
                        addLogs("反编译成功，位置：$path_decode_output")
                    } else {
                        addLogs("反编译失败！")
                    }
                } else {
                    addLogs("反编译失败，错误信息：\n: " + consequence)
                }
            }
            //重置path
            if (Process_Single) {
                path = null
            }
        }
    }
    
    //判断路径是否以“/”结尾
    private fun isPathEndsWithSlash(path: String): Boolean {
        return path.endsWith("/")
    }
    
    
}
