package com.mcyi.android.tool

import java.net.URLEncoder
import java.net.URLDecoder
import java.io.UnsupportedEncodingException
import java.nio.charset.Charset

import com.mcyi.android.library.PublicLib1

//编码操作
public class CodingOperation {

    private val mPublicLib2 : PublicLib1 = PublicLib1()

    //URL编码
    public fun URLEncoding(value : String,encoding : String = "UTF-8") : String {
        try {
			return URLEncoder.encode(value, encoding)
		} catch (e: UnsupportedEncodingException) {
			return value
		}
    }
    
    //URL解码
    public fun URLDecoding(value : String,encoding : String = "UTF-8") : String {
        try {
			return URLDecoder.decode(value, encoding)
		} catch (e: UnsupportedEncodingException) {
			return value
		}
    }
    
    //转换编码
    public fun Transcoding(Text: String?, OriginalCode: String, NewCode: String): String {
        if (Text == null) {
            return ""
        }
        try {
            return String(Text.toByteArray(Charset.forName(OriginalCode)), Charset.forName(NewCode))
        } catch (e: UnsupportedEncodingException) {
            return Text
        }
    }
    
    //UCS2编码
    fun UCS2Encoding(value: String): String {
        var str = ""
        for (i in 0 until value.length) {
            var temp = Integer.toHexString(value[i].toInt() and 65535)
            if (temp.length == 2) {
                temp = "00$temp"
            }
            str += "\\u$temp"
        }
        return str
    }
    
    //UCS2解码
    public fun UCS2Decoding(value: String): String {
        return mPublicLib2.UCS2Decoding(value)
    }
    
    //Base64编码
    fun Base64Encoding(value : String,encoding : String = "UTF-8"): String {
        return mPublicLib2.Base64Encoding(value,encoding)
    }
    
    //Base64解码
    public fun Base64Decoding(value : String,encoding : String = "UTF-8"): String {
        return mPublicLib2.Base64Decoding(value,encoding)
    }

}
