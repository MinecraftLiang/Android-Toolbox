package com.mcyi.editor.TextEditor

import android.widget.EditText
import android.content.Context
import android.graphics.drawable.Drawable
import com.mcyi.main.R
import androidx.core.content.ContextCompat
import android.text.Editable
import java.util.Stack
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import android.text.TextWatcher

class CursorModule(private val mContext: Context,private val mEditText: EditText) {

    private val undoStack = Stack<Int>() // 用于存储撤销操作的栈
    private val redoStack = Stack<Int>() // 用于存储重做操作的栈


    //初始化
    init {
        // 设置光标样式
        val cursorDrawable = ContextCompat.getDrawable(mContext, R.drawable.cursor_drawable)
        mEditText.textCursorDrawable = cursorDrawable  //VMOS虚拟机中安卓7，会引发崩溃，原因位于这里
        //
        mEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // 文本改变之前执行的操作
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // 文本改变时执行的操作
                val offset = mEditText.selectionStart // 获取光标当前位置
                push(offset)
            }

            override fun afterTextChanged(s: Editable?) {
                // 文本改变之后执行的操作
                // 可以在这里处理输入的文本
            }
        })
    }
    
    //行首
    public fun HeadLine() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var start = cursorPosition
        while (start > 0 && mEditText.text[start - 1] != '\n') {
            start--
        }
        mEditText.setSelection(start) // 将光标移动到当前行的行首
    }
    
    //行尾
    public fun EndLine() {
        val cursorPosition = mEditText.selectionStart // 获取光标位置
        var end = cursorPosition
        while (end < mEditText.text.length && mEditText.text[end] != '\n') {
            end++
        }
        mEditText.setSelection(end) // 将光标移动到当前行的行尾
    }
    
    //全文首
    public fun Head() {
        mEditText.setSelection(0) // 将光标移动到全文首
        mEditText.scrollTo(0, 0) // 编辑框自动滚动到顶部
    }
    
    //全文尾
    public fun End() {
        mEditText.setSelection(mEditText.text.length) // 将光标移动到全文尾
        mEditText.setSelection(mEditText.length(), mEditText.length()) //移动光标到最后
    }
    
    //
    
    //撤销
    public fun Undo() {
        undo()?.let { mEditText.setSelection(it) }
    }
    
    //重做
    public fun Redo() {
        redo()?.let { mEditText.setSelection(it) }
    }
    
    //记录列表
    public fun List() {
        val items = undoStack.toList().toTypedArray()
        val builder: AlertDialog.Builder = AlertDialog.Builder(mContext)
        builder.setTitle("光标记录")
        builder.setSingleChoiceItems(items.map { it.toString() }.toTypedArray(), -1) { dialog, which ->
            mEditText.setSelection(items[which])
            dialog.dismiss()
        }
        builder.setNegativeButton("关闭") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
    
    private fun push(value: Int) {
        undoStack.push(value) // 将整数入栈
        redoStack.clear() // 每次新的入栈操作，清空重做栈
    }
    
    private fun undo(): Int? {
        if (undoStack.isEmpty()) {
            return null // 撤销栈为空，无法执行撤销操作
        }
        val value = undoStack.pop() // 从撤销栈中弹出整数
        redoStack.push(value) // 将弹出的整数放入重做栈
        return value
    }
    
    private fun redo(): Int? {
        if (redoStack.isEmpty()) {
            return null // 重做栈为空，无法执行重做操作
        }
        val value = redoStack.pop() // 从重做栈中弹出整数
        undoStack.push(value) // 将弹出的整数放回撤销栈
        return value
    }
    
}
