package com.mcyi.android.library;
import java.math.BigInteger;

public class PublicLib1 {
    
    //HexString2Bytes
    public byte[] HexString2Bytes(String content,String encoding) {
        try {
			int size = content.length();
			byte[] ret = new byte[size / 2];
			byte[] tmp = content.getBytes(encoding);
			for (int i = 0; i < size / 2; i++) {
				ret[i] = uniteBytes(tmp[(i * 2)], tmp[(i * 2 + 1)]);
			  }
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
    }
    
    //uniteBytes
    public byte uniteBytes(byte byte1,byte byte2) {
		char _b0 = (char)Byte.decode("0x" + new String(new byte[] { byte1 })).byteValue();
		_b0 = (char)(_b0 << '\004');
		char _b1 = (char)Byte.decode("0x" + new String(new byte[] { byte2 })).byteValue();
		byte ret = (byte)(_b0 ^ _b1);
		return ret;
	}
    
    //UCS2Decoding
    public String UCS2Decoding(String value_text) {
		int len = value_text.length();
		StringBuffer outBuffer = new StringBuffer(len);
		int x = 0;
		while (x < len) {
			int x2 = x + 1;
			char aChar = value_text.charAt(x);
			if (aChar == '\\') {
				x = x2 + 1;
				aChar = value_text.charAt(x2);
				if (aChar == 'u') {
					int value = 0;
					int i = 0;
					while (i < 4) {
						x2 = x + 1;
						aChar = value_text.charAt(x);
						switch (aChar) {
							case '0':
							case '1':
							case '2':
							case '3':
							case '4':
							case '5':
							case '6':
							case '7':
							case '8':
							case '9':
							value = ((value << 4) + aChar) - 48;
							break;
							case 'A':
							case 'B':
							case 'C':
							case 'D':
							case 'E':
							case 'F':
							value = (((value << 4) + 10) + aChar) - 65;
							break;
							case 'a':
							case 'b':
							case 'c':
							case 'd':
							case 'e':
							case 'f':
							value = (((value << 4) + 10) + aChar) - 97;
							break;
							default:
							throw new IllegalArgumentException("Malformed	\\uxxxx	encoding.");
						}
						i++;
						x = x2;
					}
					outBuffer.append((char) value);
				} else {
					if (aChar == 't') {
						aChar = '\t';
					} else if (aChar == 'r') {
						aChar = '\r';
					} else if (aChar == 'n') {
						aChar = '\n';
					} else if (aChar == 'f') {
						aChar = '\f';
					}
					outBuffer.append(aChar);
				}
			} else {
				outBuffer.append(aChar);
				x = x2;
			}
		}
		return outBuffer.toString();
	}
    
    private final String text_set = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    
    //Base64编码
    public String Base64Encoding(String Text,String Encoding) {
        try {
        byte[] set = Text.getBytes(Encoding);
        return Base64EncodingByteSet(set,text_set);
        } catch (Exception e) {
			throw new RuntimeException("文本到字节集编码错误：" + Encoding);
		}    
    }
    
    //Base64解码
    public String Base64Decoding(String Text,String Encoding) {
        byte[] set = Base64DecodeByteSet(Text,text_set);
        try {
            return new String(set, Encoding);
        } catch (Exception e) {
			return new String(set);
		}    
    }
    
    //Base64编码_字节集
    private String Base64EncodingByteSet(byte[] Tset, String Tset2) {
		String add = "=";
		StringBuilder base64Str = new StringBuilder();
		String bytesBinary = Base64_2(Tset,2);
		int addCount = 0;
		while (bytesBinary.length() % 24 != 0) {
			bytesBinary += "0";
			addCount++;
		}
		for (int i = 0; i <= bytesBinary.length() - 6; i += 6) {
			int index = Integer.parseInt(bytesBinary.substring(i, i + 6), 2);
			if (index == 0 && i >= bytesBinary.length() - addCount) {
				base64Str.append(add);
			} else {
				base64Str.append(Tset2.charAt(index));
			}
		}
		return base64Str.toString();
	}
    
    //Base64解码_字节集
    private byte[] Base64DecodeByteSet(String Text1, String Text2) {
		String base64Binarys = "";
		for (int i = 0; i < Text1.length(); i++) {
			char s = Text1.charAt(i);
			if (s != '=') {
				String binary = Integer.toBinaryString(Text2.indexOf(s));
				while (binary.length() != 6) {
					binary = "0" + binary;
				}
				base64Binarys += binary;
			}
		}
		base64Binarys = base64Binarys.substring(0, base64Binarys.length() - base64Binarys.length() % 8);
		byte[] bytesStr = new byte[base64Binarys.length() / 8];
		for (int bytesIndex = 0; bytesIndex < base64Binarys.length() / 8; bytesIndex++) {
			bytesStr[bytesIndex] = (byte) Integer.parseInt(base64Binarys.substring(bytesIndex * 8, bytesIndex * 8 + 8), 2);
		}
		return bytesStr;
	}
    
    //Base64_到二进制
    private String Base64_2(byte[] byteSet,int number) {
        String strBytes = new BigInteger(1, byteSet).toString(number);
		while (strBytes.length() % 8 != 0) {
			strBytes = "0" + strBytes;
		}
		return strBytes;
    }
    
    
    
    
}