package com.mcyi.main.modules

import com.mcyi.main.R
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.ImageView
import android.widget.GridView
import android.widget.TextView
import android.view.LayoutInflater
import android.widget.AbsListView
import android.widget.ArrayAdapter
import java.util.ArrayList

import org.json.JSONObject
import org.json.JSONArray

import com.mcyi.android.tool2.FileOperation
import com.mcyi.android.tool2.PictureOperation

import com.mcyi.main.modules.HomeToolOpenModule

public class HomeToolListModule(private val mContext: Context,private val mGridView: GridView) {

    //列表
    private lateinit var mAdapter: ArrayAdapter<String>
    private lateinit var mItems: Array<String>
    
    //模块
    val mFileOperation: FileOperation = FileOperation()
    private var mPictureOperation : PictureOperation? = null
    
    var jsonString: String = ""
    var Type : String = "Text"
    
    //初始化
    init {
        mPictureOperation = PictureOperation(mContext)
    
        mItems = arrayOf()
    }
    
    //转换
    public fun Conversion(name : String) {
        //
        jsonString = mFileOperation.ReadResourceFile(mContext,"data/tool_list/$name.json")
        val jsonArray = JSONArray(jsonString)
        //
        val list = ArrayList<String>()
        var i = 0
        while (i < jsonArray.length()) {
            val item = jsonArray.getJSONObject(i) // 如果是 JSON 对象而不是数组，请使用 getJSONObject 方法
            list.add(item.toString())
            i++
        }
        mItems = list.toTypedArray()
    }
    
    public fun List() {
        //创建适配器
        mAdapter = ArrayAdapter(mContext, R.layout.list_tool_main, mItems)
        //设置适配器
        mGridView.adapter = mAdapter
        //刷新适配器
        mAdapter.notifyDataSetChanged()
        //自定义适配器
        class CustomAdapter(context: Context, items: Array<String>) : ArrayAdapter<String>(context, R.layout.list_tool_main, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                var view = convertView
                if (view == null) {
                    view = LayoutInflater.from(context).inflate(R.layout.list_tool_main, parent, false)
                }
                var json_string = mItems[position]
                val item = JSONObject(json_string)
                val name: String = item.getString("name")
                val icon: String = item.getString("icon")
                //获取图标
                val imageView: ImageView = view?.findViewById(R.id.icon) as ImageView
                SetPicture(imageView,icon)
                //获取名称
                val textView = view!!.findViewById<TextView>(R.id.title)
                textView.text = name
                return view
            }
        }
        //使用自定义适配器
        val customAdapter = CustomAdapter(mContext, mItems)
        mGridView.adapter = customAdapter
        //列表被点击
        mGridView.setOnItemClickListener { _, _, position, _ ->
            var json_string : String = mItems[position]
            val item = JSONObject(json_string)
            val idexs: Int = item.getString("url").toInt()
            val mHomeToolOpenModule : HomeToolOpenModule = HomeToolOpenModule(mContext)
            mHomeToolOpenModule.Open(Type,idexs)
            
        }
        //列表被长按
        mGridView.setOnItemLongClickListener { _, _, position, _ ->
            var json_string : String = mItems[position]
            
            true
        }
    }
    
    //选中
    public fun Select(itt : Int) {
        var mString : String = InttoString(itt)
        Type = mString
        Conversion(mString)
        List()
    }
    
    //过滤  已废弃
    /*
    private fun Filtration(mname : String) {
        val jsonArray = JSONArray(jsonString)
        val list = ArrayList<String>()
        list.clear()
        var i = 0
        while (i < jsonArray.length()) {
            val json_string = jsonArray.getJSONObject(i) 
            val item = JSONObject(json_string.toString())
            val name: String = item.getString("type")
            if (name.contains(mname)) {
                list.add(item.toString())
            }
            i++
        }
        mItems = list.toTypedArray()
        List()
    }
    */
    
    //转换成
    private fun InttoString(it : Int) : String {
        return when (it) {
            0 -> "Text"
            1 -> "Image"
            2 -> "System"
            3 -> "Develop"
            4 -> "Amuse"
            5 -> "Other"
            6 -> "Mcpe"
            else -> ""
        }
    }
    
    //设置图标
    private fun SetPicture(mImageView : ImageView,Name : String) {
        val pictureOperation = mPictureOperation
        if (pictureOperation != null) {
            if (Name == "") {
            } else {
                pictureOperation.setAssetsImage(mImageView,"image/tools/${Name}")
            }
        }
    }

}
