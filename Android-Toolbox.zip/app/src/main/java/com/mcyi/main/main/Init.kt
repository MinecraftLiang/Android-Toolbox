package com.mcyi.main.main

import com.mcyi.android.tool2.FileOperation

public class Init {
    
    //路径
    private var path : String = ""
    
    //文件操作
    private var mAppFileOperation : FileOperation = FileOperation()
    
    //初始化path
    public fun path(mpath : String) {
        path = mpath
    }

    //初始化
    public fun init() {
        //创建相应文件
        create_file()
    }
    
    //创建文件
    public fun create_file() {
        //创建目录
        mAppFileOperation.CreateDirectory(path + "/project")
        mAppFileOperation.CreateDirectory(path + "/backup")
        mAppFileOperation.CreateDirectory(path + "/plugin")
        mAppFileOperation.CreateDirectory(path + "/editor")
        mAppFileOperation.CreateDirectory(path + "/toolbox")
        mAppFileOperation.CreateDirectory(path + "/cache")
        mAppFileOperation.CreateDirectory(path + "/logs")
        mAppFileOperation.CreateDirectory(path + "/theme")
    }


}
