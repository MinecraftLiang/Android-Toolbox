package com.mcyi.tool.other

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
import android.content.Context
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//widget
import android.widget.LinearLayout
import androidx.appcompat.widget.Toolbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.slider.Slider
//Text
import android.text.TextWatcher
import android.text.Editable
//App
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow
import com.mcyi.android.tool.ColorOperation
import com.mcyi.android.tool.SystemOperation

public class ColorPickerActivity : AppCompatActivity() {

    //
    private var Alpha : Int = 255
    private var Red : Int = 0
    private var Green : Int = 0
    private var Blue : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_other_color_picker)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "颜色选择器"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //加载方法
        Slider_Listener()
        Copy_Listener()
    }
    
     //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //
            android.R.id.home -> {
               finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //拖动条监听器
    private fun Slider_Listener() {
        //透明度
        val slider1 = findViewById<Slider>(R.id.slider_1)
        val edit1 = findViewById<TextInputEditText>(R.id.edit_1)
        slider1.addOnChangeListener { _, value, fromUser ->
            if(fromUser) {
                Alpha = value.toInt()
                edit1.setText(value.toInt().toString())
                CompositeColor()
            }
        }
        //红色值
        val slider2 = findViewById<Slider>(R.id.slider_2)
        val edit2 = findViewById<TextInputEditText>(R.id.edit_2)
        slider2.addOnChangeListener { _, value, fromUser ->
            if(fromUser) {
                Red = value.toInt()
                edit2.setText(value.toInt().toString())
                CompositeColor()
            }
        }
        //绿色值
        val slider3 = findViewById<Slider>(R.id.slider_3)
        val edit3 = findViewById<TextInputEditText>(R.id.edit_3)
        slider3.addOnChangeListener { _, value, fromUser ->
            if(fromUser) {
                Green = value.toInt()
                edit3.setText(value.toInt().toString())
                CompositeColor()
            }
        }
        //蓝色值
        val slider4 = findViewById<Slider>(R.id.slider_4)
        val edit4 = findViewById<TextInputEditText>(R.id.edit_4)
        slider4.addOnChangeListener { _, value, fromUser ->
            if(fromUser) {
                Blue = value.toInt()
                edit4.setText(value.toInt().toString())
                CompositeColor()
            }
        }
    }
    
    //复制监听器
    private fun Copy_Listener() {
        //编辑框
        val sixteen_edit = findViewById<TextInputEditText>(R.id.sixteen_edit)
        val ten_edit = findViewById<TextInputEditText>(R.id.ten_edit)
        //复制按钮
        val copy1 = findViewById<LinearLayout>(R.id.copy1)
        val copy2 = findViewById<LinearLayout>(R.id.copy2)
        //水波纹效果
        val mViewComponent = ViewComponent()
        mViewComponent.WaterRippleEffect(this,copy1)
        mViewComponent.WaterRippleEffect(this,copy2)
        copy1.setOnClickListener {
            SystemOperation.setClipboardText(this,sixteen_edit.getText().toString())
        }
        copy2.setOnClickListener {
            SystemOperation.setClipboardText(this,ten_edit.getText().toString())
        }
    }
    
    //合成颜色
    private fun CompositeColor() {
        //合成颜色
        var output : Int = ColorOperation.getARGB(Alpha,Red,Green,Blue)
        //预览面板
        val color_panel = findViewById<LinearLayout>(R.id.color_panel)
        color_panel.setBackgroundColor(output)
        //十六进制
        val sixteen_edit = findViewById<TextInputEditText>(R.id.sixteen_edit)
        sixteen_edit.setText(ColorOperation.getColorString(output))
        //十进制
        val ten_edit = findViewById<TextInputEditText>(R.id.ten_edit)
        ten_edit.setText(output.toString())
    }
    
    
}
