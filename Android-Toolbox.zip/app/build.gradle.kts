//插件
plugins {
    id("com.android.application")
    id("kotlin-android")
}

android {
    //软件包名
    namespace = "com.mcyi.main"
    //构建工具SDK
    compileSdk = 33
    //构建工具版本
    buildToolsVersion = "34.0.4"
    //配置
    defaultConfig {
        applicationId = "com.mcyi.main"
        minSdk = 21
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
        
        vectorDrawables { 
            useSupportLibrary = true
        }
    }
    //编译选项
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    //构建类型
    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    //构建功能
    buildFeatures {
        viewBinding = true
        
    }
    
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "11"
}
//依赖
dependencies {
    //Loading Jar
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("**/*.jar","**/*.aar"))))
    //android
    //androidx
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    //material
    implementation("com.google.android.material:material:1.9.0")

}
