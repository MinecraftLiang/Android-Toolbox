package com.mcyi.main.modules

//基础库
import android.content.Context
import android.content.Intent
//
import com.mcyi.main.modules.toolopen.TextOpen
import com.mcyi.main.modules.toolopen.OtherOpen
import com.mcyi.main.modules.toolopen.MCPEOpen
import com.mcyi.main.modules.toolopen.DevelopOpen
import com.mcyi.main.modules.toolopen.AmuseOpen
//工具其他活动
import com.mcyi.tool.other.ColorPickerActivity


class HomeToolOpenModule(private val mContext: Context) {

    //
    private val mTextOpen : TextOpen = TextOpen(mContext)
    private val mOtherOpen : OtherOpen = OtherOpen(mContext)
    private val mMCPEOpen : MCPEOpen = MCPEOpen(mContext)
    private val mDevelopOpen : DevelopOpen = DevelopOpen(mContext)
    private val mAmuseOpen : AmuseOpen = AmuseOpen(mContext)

    public fun Open(type : String,index : Int) {
        when (type) {
            "Text" -> mTextOpen.Open(index)
            "Develop" -> mDevelopOpen.Open(index)
            "Amuse" -> mAmuseOpen.Open(index)
            "Other" -> mOtherOpen.Open(index)
            "Mcpe" -> mMCPEOpen.Open(index)
            else -> {}
        }
    }
}