package com.mcyi.main.modules.toolopen

//基础库
import android.content.Context
import android.content.Intent
//工具活动
import com.mcyi.tool.mcpe.SkinPreviewActivity

public class MCPEOpen(private val mContext: Context) {

    public fun Open(index : Int) {
        when (index) {
            //皮肤预览器
            0 -> {
                val intent = Intent(mContext, SkinPreviewActivity::class.java)
                mContext.startActivity(intent)
            }
            else -> {}
        }
    }


}