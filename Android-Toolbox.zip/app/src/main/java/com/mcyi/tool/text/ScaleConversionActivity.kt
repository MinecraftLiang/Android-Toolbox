package com.mcyi.tool.text

//基础库
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcyi.main.R
//
import android.widget.TextView
import android.view.View
import android.widget.Toast
import android.widget.LinearLayout
import androidx.appcompat.widget.Toolbar
//菜单
import android.view.Menu
import android.view.MenuItem
import android.view.MenuInflater
//App
import com.mcyi.android.ViewComponent
import com.mcyi.android.foundation.ApplicationWindow

public class ScaleConversionActivity : AppCompatActivity() {

    //
    private lateinit var display_text : TextView
    
    private lateinit var output_text2 : TextView
    private lateinit var output_text8 : TextView
    private lateinit var output_text10 : TextView
    private lateinit var output_text16 : TextView
    //App
    private var mViewComponent : ViewComponent = ViewComponent()
    //
    private var mText : String = ""
    private var mType = 10 //进制

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //设置视图
        setContentView(R.layout.activity_tool_text_scale_conversion)
        //设置状态栏
        ApplicationWindow.StatusBarColor(this,"#FFFFFF")
        ApplicationWindow.StatusBarFontBlack(this,true)
        val toolbar: Toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "进制转换"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.back_black)
        //
        Init()
    }
    
    //工具栏被选中事件
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //
            android.R.id.home -> {
               finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    
    //初始化
    private fun Init() {
        //控件初始化
        display_text = findViewById(R.id.display_text)
        output_text2 = findViewById(R.id.output_text2)
        output_text8 = findViewById(R.id.output_text8)
        output_text10 = findViewById(R.id.output_text10)
        output_text16 = findViewById(R.id.output_text16)
        //
        ButtonListener()
        ButtonListener2()
    }
    
    //按钮监听事件
    private fun ButtonListener() {
        //声明控件
        val button_1: LinearLayout = findViewById<LinearLayout>(R.id.button_1)
        val button_2: LinearLayout = findViewById<LinearLayout>(R.id.button_2)
        val button_3: LinearLayout = findViewById<LinearLayout>(R.id.button_3)
        val button_4: LinearLayout = findViewById<LinearLayout>(R.id.button_4)
        val button_5: LinearLayout = findViewById<LinearLayout>(R.id.button_5)
        val button_6: LinearLayout = findViewById<LinearLayout>(R.id.button_6)
        val button_7: LinearLayout = findViewById<LinearLayout>(R.id.button_7)
        val button_8: LinearLayout = findViewById<LinearLayout>(R.id.button_8)
        val button_9: LinearLayout = findViewById<LinearLayout>(R.id.button_9)
        val button_0: LinearLayout = findViewById<LinearLayout>(R.id.button_0)
        val button_a: LinearLayout = findViewById<LinearLayout>(R.id.button_a)
        val button_b: LinearLayout = findViewById<LinearLayout>(R.id.button_b)
        val button_c: LinearLayout = findViewById<LinearLayout>(R.id.button_c)
        val button_d: LinearLayout = findViewById<LinearLayout>(R.id.button_d)
        val button_e: LinearLayout = findViewById<LinearLayout>(R.id.button_e)
        val button_f: LinearLayout = findViewById<LinearLayout>(R.id.button_f)
        val button_clr: LinearLayout = findViewById<LinearLayout>(R.id.button_clr)
        val button_del: LinearLayout = findViewById<LinearLayout>(R.id.button_del)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,button_1)
        mViewComponent.WaterRippleEffect(this,button_2)
        mViewComponent.WaterRippleEffect(this,button_3)
        mViewComponent.WaterRippleEffect(this,button_4)
        mViewComponent.WaterRippleEffect(this,button_5)
        mViewComponent.WaterRippleEffect(this,button_6)
        mViewComponent.WaterRippleEffect(this,button_7)
        mViewComponent.WaterRippleEffect(this,button_8)
        mViewComponent.WaterRippleEffect(this,button_9)
        mViewComponent.WaterRippleEffect(this,button_0)
        mViewComponent.WaterRippleEffect(this,button_a)
        mViewComponent.WaterRippleEffect(this,button_b)
        mViewComponent.WaterRippleEffect(this,button_c)
        mViewComponent.WaterRippleEffect(this,button_d)
        mViewComponent.WaterRippleEffect(this,button_e)
        mViewComponent.WaterRippleEffect(this,button_f)
        mViewComponent.WaterRippleEffect(this,button_clr)
        mViewComponent.WaterRippleEffect(this,button_del)
        //
        button_1.setOnClickListener {
            if (mType >= 0) {
                add("1")
                run()
            }
        }
        button_2.setOnClickListener {
            if (mType >= 8) {
                add("2")
                run()
             }   
        }
        button_3.setOnClickListener {
            if (mType >= 8) {
                add("3")
                run()
            }    
        }
        button_4.setOnClickListener {
            if (mType >= 8) {
                add("4")
                run()
             }   
        }
        button_5.setOnClickListener {
            if (mType >= 8) {
                add("5")
                run()
            }
        }
        button_6.setOnClickListener {
            if (mType >= 8) {
                add("6")
                run()
            }    
        }
        button_7.setOnClickListener {
            if (mType >= 8) {
                add("7")
                run()
             }   
        }
        button_8.setOnClickListener {
            if (mType >= 10) {
                add("8")
                run()
            }    
        }
        button_9.setOnClickListener {
            if (mType >= 10) {
                add("9")
                run()
             }   
        }
        button_0.setOnClickListener {
            if (mType >= 0) {
                add("0")
                run()
            }    
        }
        
        button_a.setOnClickListener {
            if (mType >= 16) {
                add("A")
                run()
              }  
        }
        button_b.setOnClickListener {
            if (mType >= 16) {
                add("B")
                run()
             }   
        }
        button_c.setOnClickListener {
            if (mType >= 16) {   
                add("C")
                run()
            }    
        }
        button_d.setOnClickListener {
            if (mType >= 16) {
                add("D")
                run()
             }   
        }
        button_e.setOnClickListener {
            if (mType >= 16) {
                add("E")
                run()
             }   
        }
        button_f.setOnClickListener {
            if (mType >= 16) {
                add("F")
                run()
             }   
        }
        button_clr.setOnClickListener {
            mText = ""
            display_text.setText(mText)
            output_text2.setText("")
            output_text8.setText("")
            output_text10.setText("")
            output_text16.setText("")
        }
        button_del.setOnClickListener {
            delete()
        }
    }
    
    //按钮切换监听器
    private fun ButtonListener2() {
        //声明控件
        val toggle_button_a: LinearLayout = findViewById<LinearLayout>(R.id.toggle_button_a)
        val toggle_button_b: LinearLayout = findViewById<LinearLayout>(R.id.toggle_button_b)
        val toggle_button_c: LinearLayout = findViewById<LinearLayout>(R.id.toggle_button_c)
        val toggle_button_d: LinearLayout = findViewById<LinearLayout>(R.id.toggle_button_d)
        //设置水波纹
        mViewComponent.WaterRippleEffect(this,toggle_button_a)
        mViewComponent.WaterRippleEffect(this,toggle_button_b)
        mViewComponent.WaterRippleEffect(this,toggle_button_c)
        mViewComponent.WaterRippleEffect(this,toggle_button_d)
        //
        toggle_button_a.setOnClickListener {
            mType = 2
            toggle_button_a.setBackgroundColor(-15835393)
            toggle_button_b.setBackgroundColor(-6381922)
            toggle_button_c.setBackgroundColor(-6381922)
            toggle_button_d.setBackgroundColor(-6381922)
            reset()
        }
        toggle_button_b.setOnClickListener {
            mType = 8
            toggle_button_a.setBackgroundColor(-6381922)
            toggle_button_b.setBackgroundColor(-15835393)
            toggle_button_c.setBackgroundColor(-6381922)
            toggle_button_d.setBackgroundColor(-6381922)
            reset()
        }
        toggle_button_c.setOnClickListener {
            mType = 10
            toggle_button_a.setBackgroundColor(-6381922)
            toggle_button_b.setBackgroundColor(-6381922)
            toggle_button_c.setBackgroundColor(-15835393)
            toggle_button_d.setBackgroundColor(-6381922)
            reset()
        }
        toggle_button_d.setOnClickListener {
            mType = 16
            toggle_button_a.setBackgroundColor(-6381922)
            toggle_button_b.setBackgroundColor(-6381922)
            toggle_button_c.setBackgroundColor(-6381922)
            toggle_button_d.setBackgroundColor(-15835393)
            reset()
        }
    }
    
    //处理
    private fun run() {
      try {
        if (mText.length >= 1) {
                when (mType) {
                2 -> {
                   var value : String = mText
                   output_text2.setText(value.toString())
                   output_text8.setText(binaryToOctal(value).toString())
                   output_text10.setText(binaryToDecimal(value).toString())
                   output_text16.setText(binaryToHex(value).toString())
                }
                8 -> {
                    var value : String = mText
                    output_text2.setText(octalToBinary(value).toString())
                    output_text8.setText(value.toString())
                    output_text10.setText(octalToDecimal(value).toString())
                    output_text16.setText(octalToHex(value).toString())
                }
                10 -> {
                    var value : Int = mText.toInt()
                    output_text2.setText(decimalToBinary(value).toString())
                    output_text8.setText(decimalToOctal(value).toString())
                    output_text10.setText(value.toString())
                    output_text16.setText(decimalToHex(value).toString())
                }
                16 -> {
                    var value : String = mText
                    output_text2.setText(hexToBinary(value).toString())
                    output_text8.setText(hexToOctal(value).toString())
                    output_text10.setText(hexToDecimal(value).toString())
                    output_text16.setText(value.toString())
                }
            }
        } else {
            output_text2.setText("")
            output_text8.setText("")
            output_text10.setText("")
            output_text16.setText("")
        }
      } catch (e : Exception) {
      }
    }
    
    //输入
    private fun add(value : String) {
        var out : String = mText + value
        mText = out
        display_text.setText(mText)
        
    }
    
    //删除
    private fun delete() {
        if (mText.isNotEmpty()) {
            mText = mText.substring(0, mText.length - 1)
        }
        display_text.setText(mText)
        run()
    }
    
    //重置
    private fun reset() {
        mText = ""
        display_text.setText(mText)
        output_text2.setText("")
        output_text8.setText("")
        output_text10.setText("")
        output_text16.setText("")
    }
    
    //----转换----
    //二进制转八进制
    private fun binaryToOctal(binary: String): String {
        val decimal = Integer.parseInt(binary, 2)
        return Integer.toOctalString(decimal)
    }
    //二进制转十进制
    private fun binaryToDecimal(binary: String): Int {
        return Integer.parseInt(binary, 2)
    }
    //二进制转十六进制
    private fun binaryToHex(binary: String): String {
        val decimal = Integer.parseInt(binary, 2)
        return Integer.toHexString(decimal)
    }
    //八进制转二进制
    private fun octalToBinary(octal: String): String {
        val decimal = Integer.parseInt(octal, 8)
        return Integer.toBinaryString(decimal)
    }
    //八进制转十进制
    private fun octalToDecimal(octal: String): Int {
        return Integer.parseInt(octal, 8)
    }
    //八进制转十六进制
    private fun octalToHex(octal: String): String {
        val decimal = Integer.parseInt(octal, 8)
        return Integer.toHexString(decimal).toUpperCase()
    }
    //十进制转二进制
    private fun decimalToBinary(decimal: Int): String {
        return Integer.toBinaryString(decimal)
    }
    //十进制转八进制
    private fun decimalToOctal(decimal: Int): String {
        return Integer.toOctalString(decimal)
    }
    //十进制转十六进制
    private fun decimalToHex(decimal: Int): String {
        return Integer.toHexString(decimal)
    }
    //十六进制转二进制
    private fun hexToBinary(hex: String): String {
        val decimal = hex.toInt(16)
        return Integer.toBinaryString(decimal)
    }
    //十六进制转八进制
    private fun hexToOctal(hex: String): String {
        val decimal = hex.toInt(16)
        return Integer.toOctalString(decimal)
    }
    //十六进制转十进制
    private fun hexToDecimal(hex: String): Int {
        return hex.toInt(16)
    }
    
}
