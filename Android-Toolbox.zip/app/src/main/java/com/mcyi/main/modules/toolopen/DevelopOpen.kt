package com.mcyi.main.modules.toolopen

//基础库
import android.content.Context
import android.content.Intent
//工具活动
import com.mcyi.tool.develop.JsonToXmlActivity
import com.mcyi.tool.develop.Xml2XmlActivity
import com.mcyi.tool.develop.DexLoaderActivity

public class DevelopOpen(private val mContext: Context) {

    public fun Open(index : Int) {
        when (index) {
            //Json与Xml
            0 -> {
                val intent = Intent(mContext, JsonToXmlActivity::class.java)
                mContext.startActivity(intent)
            }
            //Xml编译或反编译
            1 -> {
                val intent = Intent(mContext, Xml2XmlActivity::class.java)
                mContext.startActivity(intent)
            }
            //Dex加载器
            2 -> {
                val intent = Intent(mContext, DexLoaderActivity::class.java)
                mContext.startActivity(intent)
            }
            else -> {}
        }
    }


}