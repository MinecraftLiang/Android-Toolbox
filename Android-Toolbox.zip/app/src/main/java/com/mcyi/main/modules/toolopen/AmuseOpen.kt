package com.mcyi.main.modules.toolopen

//基础库
import android.content.Context
import android.content.Intent
//工具活动
import com.mcyi.tool.amuse.BeautyRandomVideoActivity

public class AmuseOpen(private val mContext: Context) {

    public fun Open(index : Int) {
        when (index) {
            //随机美女视频
            0 -> {
                val intent = Intent(mContext, BeautyRandomVideoActivity::class.java)
                mContext.startActivity(intent)
            }
            else -> {}
        }
    }


}