package com.mcyi.android.tool

import java.nio.charset.Charset

//library
import com.mcyi.android.tool.PublicLib
import com.mcyi.android.library.PublicLib1
import com.mcyi.android.library.rsa
import com.mcyi.android.library.AES

//解密操作
public class DecryptionOperation {

    //PublicLib
    private val mPublicLib : PublicLib = PublicLib()
    private val mPublicLib2 : PublicLib1 = PublicLib1()

    //
    val rsa_key : Int = 528
    
    //初始化
    init {
        
    }
    
    //RSA解密
    public fun RSADecryption(value : String) : String {
        try {
            //
            var getkey : String = rsa.getkey(rsa_key)[1]
            val decryptionData = rsa.decryptByPrivateKey(value,getkey)
            return decryptionData
        } catch (e: Exception) {
            return e.message.toString()
        }
    }
    
    //AES解密
    public fun AESDecryption(value : String,password : String) : String {
        try {
            //
            if (password.length == 16) {
                val decryptionData = AES.decrypt(password,value)
                return decryptionData
            } else {
                return "密码长度必须是16"
            }
        } catch (e: Exception) {
            return "解密失败或者密码错误！"
        }
    }
    
    //RC4解密
    public fun RC4Decryption(value : String,password : String) : String {
        try {
            //
            if (password.length >= 1) {
                val decryptionData = RC4(value,password)
                return decryptionData
            } else {
                return "密码长度必须大于1"
            }
        } catch (e: Exception) {
            return e.message.toString()
        }
    }
    
    //RC4
    private fun RC4(value: String?, password: String?, encoding: Charset = Charsets.UTF_8): String {
        if (value == null || password == null) {
            return "null"
        }
        try {
            val decryptedBytes = mPublicLib.RC4Base(mPublicLib2.HexString2Bytes(value,"UTF-8"), password)
            return String(decryptedBytes, encoding)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "null"
    }
    
    
    
}
