package com.mcyi.main.modules

import com.google.android.material.tabs.TabLayout

public class HomeTabModule(private val mTabLayout: TabLayout) {

    //数组
    var TabArray: MutableList<String> = mutableListOf()
    
    private var mListeners: OnTabListener? = null
    
    init {
        TabArray = mutableListOf("文本","图像","系统","编程","娱乐","其他","MC")
    }
    
    //列表
    public fun list() {
        val tempTabArray = TabArray
            for (title in tempTabArray) {
                val tab = mTabLayout.newTab()
                tab.text = title
                mTabLayout.addTab(tab)
            }
        tempTabArray.clear()
    }
    
    //监听器
    public fun Listener() {
        // 添加选项卡点击监听器
        mTabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                // 当选项卡被选中时执行的操作
                val selectedTabIndex = tab?.position ?: -1
                mListeners?.onSelected(selectedTabIndex)
            }
        
            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // 当选项卡从选中状态变为非选中状态时执行的操作
            }
    
            override fun onTabReselected(tab: TabLayout.Tab?) {
                // 当已经选中的选项卡再次被点击时执行的操作
            }
        })
    }
    
    fun setOnTabListener(listener: OnTabListener) {
        mListeners = listener
    }    
    
    
    interface OnTabListener {
        fun onSelected(index: Int)
    }
    
}
