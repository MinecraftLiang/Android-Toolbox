package com.mcyi.editor.TextEditor

import android.widget.EditText
import android.content.Context

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.text.style.StrikethroughSpan

public class MarkingModule(private val mContext: Context,private val mEditText: EditText) {
    
    // 对文本进行蓝色高亮
    fun highlightText(start: Int, end: Int, color: Int) {
        val spannable = mEditText.text as Spannable
        val highlightSpan = ForegroundColorSpan(color)
        spannable.setSpan(highlightSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // 对文本设置黄色背景
    fun setHighlightedBackground(start: Int, end: Int, color: Int) {
        val spannable = mEditText.text as Spannable
        val backgroundSpan = BackgroundColorSpan(color)
        spannable.setSpan(backgroundSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
        
    // 给文本添加下划线
    fun underlineText(start: Int, end: Int) {
        val spannable = mEditText.text as Spannable
        val underlineSpan = UnderlineSpan()
        spannable.setSpan(underlineSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }    

    // 给文本添加斜体
    fun italicText(start: Int, end: Int) {
        val spannable = mEditText.text as Spannable
        val italicSpan = StyleSpan(Typeface.ITALIC)
        spannable.setSpan(italicSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // 给文本添加粗体
    fun boldText(start: Int, end: Int) {
        val spannable = mEditText.text as Spannable
        val boldSpan = StyleSpan(Typeface.BOLD)
        spannable.setSpan(boldSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // 给文本添加删除线
    fun strikethroughText(start: Int, end: Int) {
        val spannable = mEditText.text as Spannable
        val strikethroughSpan = StrikethroughSpan()
        spannable.setSpan(strikethroughSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    
}
