package com.mcyi.android.tool

//java
import java.nio.charset.Charset
import java.util.*
import java.security.*
import java.math.*
import java.util.zip.CRC32
import java.math.BigInteger

//library
import com.mcyi.android.tool.PublicLib
import com.mcyi.android.library.rsa
import com.mcyi.android.library.AES

//加密操作
public class EncryptionOperation {

    //PublicLib
    private val mPublicLib : PublicLib = PublicLib()

    //
    val rsa_key : Int = 528
    
    //初始化
    init {
        
    }

    //MD5加密
    public fun MD5Encryption(value : String,encoding : String = "UTF-8") : String {
        val hexDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f')
        try {            
            val btInput = value.toByteArray(Charset.forName(encoding))
            val mdInst = MessageDigest.getInstance("MD5")
            mdInst.update(btInput)
            val md = mdInst.digest()
            val j = md.size
            val str = CharArray(j * 2)
            var k = 0
            for (i in 0 until j) {
            val byte0 = md[i]
            str[k++] = hexDigits[(byte0.toInt() and 0xff) shr 4]
            str[k++] = hexDigits[byte0.toInt() and 0x0f]
            }
            return String(str)
        } catch (e: Exception) {
            e.printStackTrace()
            return "null"
        }
    }
    
    //CRC32加密
    public fun CRC32Encryption(value: String): String {
        val data = value.toByteArray()
        val crc32 = CRC32()
        crc32.update(data)
        return crc32.value.toString()
    }
    
    //SHA加密
    public fun SHAEncryption(value : String,encoding : String = "UTF-8") : String {
        try {
            val sha = MessageDigest.getInstance("SHA")
            sha.update(value.toByteArray(Charset.forName(encoding)))
            return String(sha.digest(), Charset.forName(encoding))
        } catch (e: Exception) {
            return "null"
        }
    }
    
    //RSA加密
    public fun RSAEncryption(value : String) : String {
        try {
            //
            var getkey : String = rsa.getkey(rsa_key)[0]
            val encryptedData = rsa.encryptByPublicKey(value,getkey)
            return encryptedData
        } catch (e: Exception) {
            return e.message.toString()
        }
    }
    
    //AES加密
    public fun AESEncryption(value : String,password : String) : String {
        try {
            //
            if (password.length == 16) {
                val encryptedData = AES.encrypt(password,value)
                return encryptedData
            } else {
                return "密码长度必须是16"
            }
        } catch (e: Exception) {
            return e.message.toString()
        }
    }
    
    //RC4加密
    public fun RC4Encryption(value : String,password : String) : String {
        try {
            //
            if (password.length >= 1) {
                val encryptedData = RC4(value,password)
                return encryptedData
            } else {
                return "密码长度必须大于1"
            }
        } catch (e: Exception) {
            return e.message.toString()
        }
    }
    
    //RC4
    private fun RC4(value: String?, password: String?, encoding: Charset = Charsets.UTF_8): String {
        if (value == null || password == null) {
            return "null"
        }
        try {
            val encryptedBytes = mPublicLib.RC4Base(value.toByteArray(encoding), password)
            val hexDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F')
            val j = encryptedBytes.size
            val str = CharArray(j * 2)
            var k = 0
            for (i in 0 until j) {
                val byte0 = encryptedBytes[i]
                str[k++] = hexDigits[byte0.toInt() ushr 4 and 0xF]
                str[k++] = hexDigits[byte0.toInt() and 0xF]
            }
            return String(str)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "null"
    }

   

}