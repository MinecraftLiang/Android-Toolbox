package com.mcyi.editor.TextEditor

import android.widget.EditText
import android.content.Context
import android.util.TypedValue
import android.view.ScaleGestureDetector

class ZoomModule(private val mContext: Context,private val mEditText: EditText) {

    //初始化ScaleGestureDetector
    val scaleGestureDetector = ScaleGestureDetector(mContext, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val scaleFactor = detector.scaleFactor
            // 根据缩放因子调整字体大小
            val currentFontSize = mEditText.textSize
            val newFontSize = currentFontSize * scaleFactor
            val newFontSizeInt = newFontSize.toInt()
            if (newFontSizeInt < 100) {
                if (newFontSizeInt > 30) {
                    mEditText.setTextSize(TypedValue.COMPLEX_UNIT_PX, newFontSize)
                }
            }
            return true
        }
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            // 设置编辑框焦点为不可用状态，防止弹出输入法
            mEditText.clearFocus()
            return true
        }
        override fun onScaleEnd(detector: ScaleGestureDetector) {
            
        }
    })
    
    //初始化
    init {
        //
        mEditText.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            false
        }
    }
    
}
