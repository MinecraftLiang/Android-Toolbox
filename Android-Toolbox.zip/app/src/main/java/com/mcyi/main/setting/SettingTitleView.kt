package com.mcyi.main.setting

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.TextView
import android.view.LayoutInflater
import com.mcyi.main.R

class SettingTitleView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : FrameLayout(context, attrs, defStyle) {

    private lateinit var title: TextView

    init {
        LayoutInflater.from(context).inflate(R.layout.view_setting_title, this, true)
        // 获取 XML 布局文件中的控件，并在此处对其进行操作
        title = findViewById(R.id.title)
    }

    //设置标题
    fun setTitle(value: String) {
        title.text = value
    }
    
    
}